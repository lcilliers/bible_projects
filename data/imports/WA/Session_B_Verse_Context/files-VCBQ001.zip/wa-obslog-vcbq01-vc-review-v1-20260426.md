# wa-obslog-vcbq01-vc-review-v1-20260426.md

**Session:** VCB-Q01  
**Reference:** VCB-Q01  
**Session name:** vc-review  
**Governing instruction:** wa-versecontext-instruction-v3_10-20260425.md  
**Global rules:** wa-global-rules-all-v1-20260426.md (34 rules, 12 categories — loaded)  
**Date:** 2026-04-26  
**Obslog version:** v1 (initial)  
**Previous outputs:** None — new session  

---

## STARTUP — GR-LOAD-001 Compliance

**(1) Rules loaded:** wa-global-rules-all-v1-20260426.md — 34 rules across 12 categories. ✓  
**(2) Observations log initialised:** this file — wa-obslog-vcbq01-vc-review-v1-20260426.md ✓  
**(3) Cadence discipline activated:** M1+M4 active — self-check will precede every substantive response; present_files will follow every substantive write. ✓  

**Session A content boundary understood:** Session A carries STEP-sourced data only; no downstream-stage content is read from it or written into it.  
**Verse Context role understood:** classify verses by term-level inner-being engagement; produce anchors; defer all interpretation to Session B.

---

## SESSION COMPOSITION

**Terms in session:** 6  
**Total verses across terms:** 2 + 43 + 14 + 11 + 12 + 2 = 84 verses  
**Previously classified verses (from active rows):** 2 + 43 + 14 + 11 + 12 + 2 = 84 (all terms have existing rows — RE-EVALUATION posture for all)

**Term inventory (session composition order = file order presented by researcher):**

| # | Strong's | Transliteration | Gloss | Registry | mti_id | md_version | vc_status | Verses | Existing groups | Posture |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | G3948 | paroxusmos | stirring up | 004 anger | 1562 | v1 | not_done | 2 | 2 active | RE-EVALUATION |
| 2 | H6293 | pa.ga | to fall on | 094 intercession | 937 | v2 | vc_completed | 43 | 2 active | RE-EVALUATION |
| 3 | G0544 | apeitheō | to disobey | 165 unbelief | 1199 | v2 | vc_completed | 14 | 5 active | RE-EVALUATION |
| 4 | G0570 | apistia | unbelief | 165 unbelief | 1198 | v2 | vc_completed | 11 | 8 active | RE-EVALUATION |
| 5 | G4710 | spoudē | diligence | 181 zeal | 1268 | v2 | vc_completed | 12 | 11 active | RE-EVALUATION |
| 6 | G3878 | parakouō | to ignore | 050 disobedience | 5111 | v2 | vc_completed | 2 | 1 active | RE-EVALUATION |

---

## VERSION ACKNOWLEDGEMENTS (A-03 gate)

- **G3948** mti_id=1562 loaded at md_version=v1. This is the version that will be declared in the patch's `_patch_meta.input_versions[1562]`. If the DB's md_version for this term has changed by the time the patch is submitted, the patch will be rejected as stale.
- **H6293** mti_id=937 loaded at md_version=v2. `input_versions[937]` = 2.
- **G0544** mti_id=1199 loaded at md_version=v2. `input_versions[1199]` = 2.
- **G0570** mti_id=1198 loaded at md_version=v2. `input_versions[1198]` = 2.
- **G4710** mti_id=1268 loaded at md_version=v2. `input_versions[1268]` = 2.
- **G3878** mti_id=5111 loaded at md_version=v2. `input_versions[5111]` = 2.

---

## PRIOR-STATE POSTURE DECLARATIONS

**G3948** (paroxusmos) mti_id=1562: RE-EVALUATION. 2 active `verse_context_group` rows and 0 dissolved rows are present for this term. Every prior classification will be reviewed against the current filter and grouping model. Every pre-existing active group will be accounted for at term close — either retained with verses, dissolved, or carried without verses with a documented reason. No silent pass-through.

> ⚠ ANOMALY NOTED: G3948 `vc_status = not_done` BUT has 2 existing verse_context rows and 2 active groups. This is an inconsistency — vc_status has not been advanced to vc_completed despite existing classification data. This term's patch must flip vc_status to vc_completed. Flagged for obslog tracking. This does not block classification.

**H6293** (pa.ga) mti_id=937: RE-EVALUATION. 2 active `verse_context_group` rows and 0 dissolved rows are present for this term. Every prior classification will be reviewed. No silent pass-through.

**G0544** (apeitheō) mti_id=1199: RE-EVALUATION. 5 active `verse_context_group` rows and 0 dissolved rows are present for this term. Every prior classification will be reviewed. No silent pass-through.

**G0570** (apistia) mti_id=1198: RE-EVALUATION. 8 active `verse_context_group` rows and 0 dissolved rows are present for this term. Every prior classification will be reviewed. No silent pass-through.

**G4710** (spoudē) mti_id=1268: RE-EVALUATION. 11 active `verse_context_group` rows and 0 dissolved rows are present for this term. Every prior classification will be reviewed. No silent pass-through.

**G3878** (parakouō) mti_id=5111: RE-EVALUATION. 1 active `verse_context_group` row and 0 dissolved rows are present for this term. Every prior classification will be reviewed. No silent pass-through.

---

## TERM 1: G3948 *paroxusmos* — stirring up | Registry 004 anger | mti_id=1562

**Opened:** 2026-04-26  
**md_version:** v1  
**Verses:** 2 active  
**Existing groups:** 1562-001 (sharp inner conflict of disagreement), 1562-002 (deliberate inner-stimulation toward love and good works)

### Step 1: Read all verses — lexical orientation

**Lexical range:** *paroxusmos* — two distinct semantic poles in its 4-occurrence NT corpus:
- Sense 1: sharp fit of anger / sharp contention / angry dispute → Acts 15:39
- Sense 2: inciting, incitement, stirring up → Heb 10:24

Only 2 verses are in the active corpus (VERSE_EVIDENCE_CONCENTRATED flag applies). Both poles are represented.

### Step 2: Verse-by-verse filter assessment

**vid=65317 — Act 15:39** | target: `sharp disagreement`
> "And there arose a sharp disagreement, so that they separated from each other. Barnabas took Mark with him and sailed away to Cyprus,"

**Filter assessment:** Does *paroxusmos*, in this verse, say something about the inner being?
- The term names the acute interpersonal conflict between Paul and Barnabas — a `sharp disagreement` so intense it caused separation.
- The inner-being engagement: *paroxusmos* here names the inner state of sharp contention — the cutting edge of conviction-driven conflict between two persons. The separation is the external consequence; the *paroxusmos* is the inner state that generated it.
- **Observation:** The prior group description ("sharp inner conflict of disagreement — the cutting edge of contention between persons of conviction") correctly identifies this as characteristic-perspective: the characteristic is the inner state of sharp contention/anger, the term names it directly.
- **Decision:** RELEVANT. Prior classification confirmed.
- **Prior:** relevant · anchor · group=1562-001. CONFIRMED. No revision warranted.

**vid=65318 — Heb 10:24** | target: `stir up`
> "And let us consider how to stir up one another to love and good works,"

**Filter assessment:** Does *paroxusmos*, in this verse, say something about the inner being?
- The term here names a deliberate act of inner-stimulation directed at another's inner life — the purposeful provoking of another toward love and good works.
- The inner-being engagement: *paroxusmos* names the intentional stimulation of another's inner disposition — it is the mechanism by which love (an inner characteristic) is activated in others. The term is implicated in the inner-being characteristic of love as the object being provoked, and of intentional relational action as the mechanism.
- Prior group description: "deliberate inner-stimulation toward love and good works — the intentional provoking of others' inner life toward what is good." This is characteristic-perspective: the characteristic is love/good works (inner disposition), the term names the provoking mechanism.
- **Decision:** RELEVANT. Prior classification confirmed.
- **Prior:** relevant · anchor · group=1562-002. CONFIRMED. No revision warranted.

### Step 3: Grouping review

Both existing groups confirmed appropriate:
- **1562-001:** "Term names the sharp inner conflict of disagreement — the cutting edge of contention between persons of conviction" — characteristic-perspective ✓, grounded in Act 15:39 ✓
- **1562-002:** "Term names the deliberate inner-stimulation toward love and good works — the intentional provoking of others' inner life toward what is good" — characteristic-perspective ✓, grounded in Heb 10:24 ✓

No consolidation needed (2 groups, 1 verse each, materially different inner-being characteristics: anger/contention vs intentional encouragement).

### Step 4: Anchor designation

- vid=65317 (Act 15:39) is anchor for 1562-001 — confirmed. Term meaning unambiguous; verse stands alone.
- vid=65318 (Heb 10:24) is anchor for 1562-002 — confirmed. Term meaning unambiguous; verse stands alone.

Both groups have exactly 1 anchor each. Rule R4 satisfied.

### Step 5: Dual-context

No verses operate at two distinct inner-being levels. Both single-verse groups are clean.

### Step 6: RE-EVALUATION SELF-CHECK

> *"Re-evaluation self-check for G3948 (paroxusmos) mti_id=1562:*
> *— Active verses: 2*
> *— Prior classifications reviewed: 2 (every active verse — mandatory)*
> *— Confirmed unchanged (is_relevant + group + is_anchor all unchanged): 2*
> *— Revised is_relevant: 0*
> *— Revised group assignment: 0*
> *— Promoted to anchor: 0*
> *— Demoted from anchor: 0*
> *— Check: 2 + 0 + 0 = 2? YES"*

### ORPHAN-GROUP CHECK

> *"Orphan-group check for G3948 mti_id=1562:*
> *— Pre-existing active groups: 2*
> *— Active verse counts per group after re-classification: {1562-001: 1, 1562-002: 1}*
> *— Orphan groups (0 active verses): NONE*
> *— Disposition per orphan: N/A"*

### TERM 1 SUMMARY

```
Term: G3948 (paroxusmos) — stirring up
mti_term_id: 1562
OWNER for: anger (registry 004)
Total verses: 2 | Relevant: 2 | Set aside: 0

Groups:
  1562-001 [existing, confirmed]: "Term names the sharp inner conflict of disagreement — the cutting edge of contention between persons of conviction"
    Anchors: Act 15:39 (vid=65317)
    Related: 0 verses
  1562-002 [existing, confirmed]: "Term names the deliberate inner-stimulation toward love and good works — the intentional provoking of others' inner life toward what is good"
    Anchors: Heb 10:24 (vid=65318)
    Related: 0 verses

Revisions to prior classifications: 0
Dual-context verses: 0
Borderline retained: 0
Anchor integrity: confirmed — 2 active anchors across 2 groups

Patch-contribution class: NO-CHANGE (RE-EVALUATION; full review confirms all existing classifications correct; no operations of any kind)
Declared in terms_covered of: VCREVISE (empty-ops pattern, per §7.9.3b)
```

**⚠ ANOMALY RECORD — G3948 vc_status:** This term has `vc_status = not_done` despite having complete classification data (2 rows, 2 groups, both anchors present). The empty-ops VCREVISE will advance the vc_status to vc_completed via the applicator. This is the correct resolution path. No additional patch operation needed — the terms_covered declaration + version gate will trigger the flip.

---

## TERM 2: H6293 *pa.ga* — to fall on | Registry 094 intercession | mti_id=937

**Opened:** 2026-04-26  
**md_version:** v2  
**Verses:** 43 active  
**Existing groups:** 937-001 (inner act of intercession — entreaty/pleading), 937-002 (substitutionary laying of iniquity on another)

### Step 1: Lexical orientation

**H6293** *pa.ga* has a wide semantic range across two stems:
- Qal: meet, light upon, join; meet of kindness; fall upon (hostility); entreat (request); touch (boundary)
- Hiphil: cause to light upon; cause to entreat; make entreaty/interpose; make attack; reach the mark

The registry is `intercession`, so the inner-being engagement axis is the entreat/interpose dimension — but the full corpus must be read to determine which verses carry that dimension in the term itself vs. other terms.

### Step 2: Verse-by-verse filter assessment

**vid=28154 — Gen 23:8** | target: `entreat`
> "And he said to them, 'If you are willing that I should bury my dead out of my sight, hear me and entreat for me Ephron the son of Zohar,'"
- *pa.ga* here = entreat on behalf of (Hiphil sense 1b2). The act of entreating/interceding on behalf of Abraham before Ephron. This is an act of relational mediation/petition — inner-being relevant as it names the disposition of one person interceding for another.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=28155 — Gen 28:11** | target: `came to`
> "And he came to a certain place and stayed there that night..."
- *pa.ga* = spatial arrival. No inner-being content carried by this term.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=28156 — Gen 32:1** | target: `met`
> "Jacob went on his way, and the angels of God met him."
- *pa.ga* = spatial/narrative meeting. No inner-being content in this term's use.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175146 — Exo 5:3** | target: `fall`
> "...lest he fall upon us with pestilence or with the sword."
- *pa.ga* = hostile falling upon (physical threat). No inner-being engagement by this term.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175145 — Exo 5:20** | target: `met`
> "They met Moses and Aaron, who were waiting for them..."
- *pa.ga* = spatial/narrative encounter. No inner-being content.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175144 — Exo 23:4** | target: `meet`
> "If you meet your enemy's ox or his donkey going astray, you shall bring it back to him."
- *pa.ga* = chance encounter (spatial). No inner-being engagement.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=28171 — Num 35:19** | target: `meets`
> "The avenger of blood shall himself put the murderer to death; when he meets him, he shall put him to death."
- *pa.ga* = physical encounter/attack. Legal-procedural; no inner-being content.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=28172 — Num 35:21** | target: `meets`
> "...the avenger of blood shall put the murderer to death when he meets him."
- Same pattern as Num 35:19. Physical/legal encounter.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175154 — Jos 2:16** | target: `encounter`
> "Go into the hills, or the pursuers will encounter you..."
- *pa.ga* = physical encounter/chance meeting. Narrative/spatial. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175147 — Jos 16:7** | target: `touches`
> "then it goes down from Janoah to Ataroth and to Naarah, and touches Jericho, ending at the Jordan."
- *pa.ga* = boundary touching (spatial/geographical). Clearly spatial_only.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=175148 — Jos 17:10** | target: `forming`
> "...with the sea forming its boundary. On the north Asher is reached..."
- *pa.ga* = geographical boundary reach. Spatial.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=175149 — Jos 19:11** | target: `to`
> "...then their boundary goes up westward and on to Mareal and touches Dabbesheth..."
- *pa.ga* = spatial boundary touch.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=175150 — Jos 19:22** | target: `touches`
> "The boundary also touches Tabor, Shahazumah, and Beth-shemesh..."
- Spatial boundary.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=175151 — Jos 19:26** | target: `touches`
> "...On the west it touches Carmel and Shihor-libnath,"
- Spatial boundary.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=175152 — Jos 19:27** | target: `touches`
> "...it goes to Beth-dagon, and touches Zebulun and the Valley of Iphtahel..."
- Spatial boundary.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=175153 — Jos 19:34** | target: `touching`
> "...touching Zebulun at the south and Asher on the west and Judah on the east at the Jordan."
- Spatial boundary.
- **Filter decision:** SET ASIDE. Prior: set aside — spatial_only. CONFIRMED.

**vid=28170 — Judg 8:21** | target: `fall`
> "Then Zebah and Zalmunna said, 'Rise yourself and fall upon us, for as the man is, so is his strength.'"
- *pa.ga* = hostile attack/execution. Physical act. The saying "as the man is, so is his strength" is not carried by *pa.ga* but by the broader discourse. *pa.ga* = the physical fall upon.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=28168 — Judg 15:12** | target: `attack`
> "And Samson said to them, 'Swear to me that you will not attack me yourselves.'"
- *pa.ga* = physical attack. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=28169 — Judg 18:25** | target: `fall`
> "...lest angry fellows fall upon you, and you lose your life with the lives of your household."
- *pa.ga* = hostile physical attack. The anger is carried by *mare* (bitter of soul) — not by *pa.ga*.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175155 — Rut 1:16** | target: `urge`
> "But Ruth said, 'Do not urge me to leave you or to return from following you...'"
- *pa.ga* = entreat/urge (Hiphil sense). Ruth is telling Naomi not to press/entreat her to return. The inner-being content: the act of urging/entreating implies a relational disposition — loyalty, devotion. The term *pa.ga* here names the act of intercession/entreaty in relational context.
- **Filter assessment:** This verse has genuine inner-being content (Ruth's loyalty, devotion, relational self-giving) — but is the inner-being content carried by *pa.ga* or by the rest of the verse? Ruth says "do not urge me" — *pa.ga* names Naomi's potential act of entreating, not the inner state itself. However, the act of entreating/urging presupposes an inner orientation toward the one being urged. The term is implicated in the relational disposition.
- **In-session resolution:** The prior group 937-001 is about intercession/entreaty before God or on behalf of others — a spiritual/relational register. Rut 1:16 uses *pa.ga* in the interpersonal register (Naomi to Ruth). The characteristic being served is different in register but similar in type: entreating another. The prior classification as related to 937-001 is defensible — the characteristic of intercession/entreaty is the same. No revision clearly warranted.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=175156 — Rut 2:22** | target: `assaulted`
> "...lest in another field you be assaulted."
- *pa.ga* = hostile encounter/attack. Physical danger. No inner-being engagement.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175139 — 1Sa 10:5** | target: `meet`
> "...you will meet a group of prophets coming down from the high place..."
- *pa.ga* = chance/narrative encounter. No inner-being engagement by this term.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175140 — 1Sa 22:17** | target: `strike`
> "...But the servants of the king would not put out their hand to strike the priests of the Lord."
- *pa.ga* = physical attack. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175141 — 1Sa 22:18** | target: `strike`
> "Then the king said to Doeg, 'You turn and strike the priests.'"
- *pa.ga* = physical attack. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175142 — 2Sa 1:15** | target: `execute`
> "Then David called one of the young men and said, 'Go, execute him.'"
- *pa.ga* = ordered execution/physical attack. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175133 — 1Ki 2:25** | target: `struck`
> "So King Solomon sent Benaiah the son of Jehoiada, and he struck him down, and he died."
- *pa.ga* = physical striking. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175134 — 1Ki 2:29** | target: `down`
> "...Solomon sent Benaiah the son of Jehoiada, saying, 'Go, strike him down.'"
- *pa.ga* = execution command. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175135 — 1Ki 2:31** | target: `down`
> "...Do as he has said, strike him down and bury him..."
- *pa.ga* = execution. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175136 — 1Ki 2:32** | target: `attacked`
> "...he attacked and killed with the sword two men more righteous and better than himself..."
- *pa.ga* = violent attack. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175137 — 1Ki 2:34** | target: `struck him down`
> "Then Benaiah...struck him down and put him to death."
- *pa.ga* = execution. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=175138 — 1Ki 2:46** | target: `struck him down`
> "...he went out and struck him down, and he died."
- *pa.ga* = execution. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=28166 — Job 21:15** | target: `pray`
> "What is the Almighty, that we should serve him? And what profit do we get if we pray to him?"
- *pa.ga* = to entreat/pray (to reach out to God). The wicked's rhetorical rejection of prayer. The inner-being content: the act of praying to God presupposes orientation of the inner person toward God; here the term names that orientation in its rejection (rhetorical question expressing contempt for intercession). The term is implicated in the inner-being characteristic of prayer/orientation toward God.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=28167 — Job 36:32** | target: `mark`
> "He covers his hands with the lightning and commands it to strike the mark."
- *pa.ga* = to reach the mark (Hiphil 1b5). Physical/cosmic — no inner-being engagement.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

**vid=28157 — Isa 47:3** | target: `spare`
> "Your nakedness shall be uncovered, and your disgrace shall be seen. I will take vengeance, and I will spare no one."
- *pa.ga* here = "I will not meet/spare [anyone]" — Hiphil used in the negative, meaning God will not intercede/intervene for Babylon. The inner-being content: the absence of intercession/mercy. This is more complex — the term names the non-occurrence of a relational act. Prior classification as relevant/related/937-001 was based on this.
- **In-session resolution:** The characteristic being engaged is intercession/mercy — the term names its absence ("will spare no one" = will make no intercession/will not hold back). This is the inner-being characteristic of 937-001 (intercession) engaged negatively. The prior classification as related is defensible. No revision clearly warranted.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=28159 — Isa 53:6** | target: `laid`
> "All we like sheep have gone astray; we have turned — every one — to his own way; and the Lord has laid on him the iniquity of us all."
- *pa.ga* (Hiphil) = to cause to fall upon / to lay upon. The Lord caused the iniquity of all to fall upon the Servant. This is 937-002 territory — substitutionary moral burden. The inner-being content: moral guilt/iniquity (inner-being characteristic) being transferred to another.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=937-002. CONFIRMED.

**vid=28158 — Isa 53:12** | target: `makes intercession`
> "...he bore the sin of many, and makes intercession for the transgressors."
- *pa.ga* = intercession (Hiphil, make entreaty). The clearest intercession use. Inner-being content: the act of interceding on behalf of others before God.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=937-001. CONFIRMED.

**vid=28160 — Isa 59:16** | target: `intercede`
> "He saw that there was no man, and wondered that there was no one to intercede..."
- *pa.ga* = intercede. The absence of intercession as a moral absence. Inner-being content: the act of interceding (and here its absence as moral failure).
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=28161 — Isa 64:5** | target: `meet`
> "You meet him who joyfully works righteousness, those who remember you in your ways..."
- *pa.ga* = encounter/meet (God meeting/encountering those who seek him). The prior classification was revised to wrong_face: the inner-being content (joyful righteousness, remembering God) is carried by other terms; *pa.ga* names the encounter act only.
- **In-session re-read:** The verse shows God encountering those who joyfully work righteousness. Does *pa.ga* carry any inner-being content? The meeting/encountering here could be read as God's responsive disposition — but the inner-being characteristics (joyful works, remembrance) are carried by the participial clauses, not by *pa.ga*. The term names the relational encounter act.
- **Prior:** set aside — wrong_face (revised in re-evaluation v3_10). Notes: "inner-being content (joyful righteousness, remembering God) is carried by other terms; pa.ga names the encounter act only."
- **Assessment:** The prior revision is well-reasoned. *pa.ga* here is the encounter verb; the inner-being content is in the participial modifiers. The wrong_face designation is appropriate.
- **Filter decision:** SET ASIDE (wrong_face). Prior classification confirmed. CONFIRMED.

**vid=28165 — Jer 7:16** | target: `intercede`
> "...do not intercede with me, for I will not hear you."
- *pa.ga* = intercede. God prohibiting Jeremiah from interceding for the people. The inner-being content: the act of intercession (and its prohibition reveals its inner-being character as a relational disposition toward God on behalf of others).
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=937-001. CONFIRMED.

**vid=28162 — Jer 15:11** | target: `pleaded`
> "Have I not set you free for their good? Have I not pleaded for you before the enemy..."
- *pa.ga* = to plead for / intercede. God himself is described as having interceded/pleaded for Jeremiah. Inner-being content: intercession as relational act.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=28163 — Jer 27:18** | target: `intercede`
> "...let them intercede with the Lord of hosts, that the vessels...may not go to Babylon."
- *pa.ga* = intercede. Direct intercession petition. Inner-being content: intercession as inner relational act toward God.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=28164 — Jer 36:25** | target: `urged`
> "Even when Elnathan and Delaiah and Gemariah urged the king not to burn the scroll..."
- *pa.ga* = to urge/entreat. Interpersonal entreaty. Inner-being content: the act of entreating another (intercession in interpersonal register — cf. Ruth 1:16).
- **Filter decision:** RELEVANT. Prior: relevant · related · group=937-001. CONFIRMED.

**vid=175143 — Amo 5:19** | target: `met`
> "...as if a man fled from a lion, and a bear met him..."
- *pa.ga* = narrative encounter/chance meeting. No inner-being.
- **Filter decision:** SET ASIDE. Prior: set aside — no_inner_being. CONFIRMED.

### Step 3: Grouping review

All 43 verses reviewed. Results:
- **937-001 (intercession):** Gen 23:8, Rut 1:16, Job 21:15, Isa 47:3, Isa 53:12, Isa 59:16, Jer 7:16, Jer 15:11, Jer 27:18, Jer 36:25 = 10 relevant verses
- **937-002 (substitutionary burden):** Isa 53:6 = 1 relevant verse
- Set aside (spatial_only): Gen 28:11, Jos 16:7, Jos 17:10, Jos 19:11, Jos 19:22, Jos 19:26, Jos 19:27, Jos 19:34 = 8 verses
- Set aside (no_inner_being): Gen 32:1, Exo 5:3, Exo 5:20, Exo 23:4, Num 35:19, Num 35:21, Jos 2:16, Judg 8:21, Judg 15:12, Judg 18:25, Rut 2:22, 1Sa 10:5, 1Sa 22:17, 1Sa 22:18, 2Sa 1:15, 1Ki 2:25, 1Ki 2:29, 1Ki 2:31, 1Ki 2:32, 1Ki 2:34, 1Ki 2:46, Job 36:32, Amo 5:19 = 23 verses
- Set aside (wrong_face): Isa 64:5 = 1 verse

**Total: 11 relevant + 32 set aside = 43 ✓**

Both existing groups retain active verses. No orphan groups. Group descriptions remain appropriate.

### Step 4: Anchor review

- **937-001:** Isa 53:12 (anchor) — "makes intercession for the transgressors" — unambiguous, stands alone. ✓ Jer 7:16 is second anchor — "do not intercede with me" — clear. ✓ (2 anchors)
- **937-002:** Isa 53:6 (anchor) — "the Lord has laid on him the iniquity of us all" — clear substitutionary sense. ✓ (1 anchor)

Rule R4 satisfied.

### Step 6: RE-EVALUATION SELF-CHECK

> *"Re-evaluation self-check for H6293 (pa.ga) mti_id=937:*
> *— Active verses: 43*
> *— Prior classifications reviewed: 43 (every active verse — mandatory)*
> *— Confirmed unchanged: 43*
> *— Revised is_relevant: 0*
> *— Revised group assignment: 0*
> *— Promoted to anchor: 0*
> *— Demoted from anchor: 0*
> *— Check: 43 + 0 + 0 = 43? YES"*

**Note:** vid=28161 (Isa 64:5) was previously revised to wrong_face in a prior session (v3_10 re-evaluation). This session confirms that revision as correct. It shows as already set aside in the current data — no further change needed.

### ORPHAN-GROUP CHECK

> *"Orphan-group check for H6293 mti_id=937:*
> *— Pre-existing active groups: 2*
> *— Active verse counts: {937-001: 10, 937-002: 1}*
> *— Orphan groups: NONE*
> *— Disposition: N/A"*

### TERM 2 SUMMARY

```
Term: H6293 (pa.ga) — to fall on
mti_term_id: 937
OWNER for: intercession (registry 094)
Total verses: 43 | Relevant: 11 | Set aside: 32

Groups:
  937-001 [existing, confirmed]: "Term names the inner act of intercession — entreaty or pleading on behalf of another before God, or the absence of such intercession as a moral absence"
    Anchors: Isa 53:12 (vid=28158), Jer 7:16 (vid=28165)
    Related: 8 verses (Gen 23:8, Rut 1:16, Job 21:15, Isa 47:3, Isa 59:16, Jer 15:11, Jer 27:18, Jer 36:25)
  937-002 [existing, confirmed]: "Term names the substitutionary laying of iniquity on another — the moral burden of the many placed on the one who bears it"
    Anchors: Isa 53:6 (vid=28159)
    Related: 0 verses

Revisions to prior classifications: 0
Dual-context verses: 0
Borderline retained: 0
Anchor integrity: confirmed — 3 active anchors across 2 groups

Patch-contribution class: NO-CHANGE
Declared in terms_covered of: VCREVISE (empty-ops)
```

---

## TERM 3: G0544 *apeitheō* — to disobey | Registry 165 unbelief | mti_id=1199

**Opened:** 2026-04-26  
**md_version:** v2  
**Verses:** 14 active  
**Existing groups:** 1199-001 through 1199-005

### Step 1: Lexical orientation

*apeitheō* = to be uncompliant; to refuse belief; to refuse belief and obedience; to refuse conformity. The term operates across a spectrum from pure unbelief (refusing the gospel) to covenant-historical corporate disobedience to moral non-conformity. All senses connect to inner-being: the will/disposition toward or against truth, God's revelation, and moral demands.

### Step 2: Verse-by-verse filter assessment

**vid=204810 — Joh 3:36** | target: `not obey`
> "Whoever believes in the Son has eternal life; whoever does not obey the Son shall not see life, but the wrath of God remains on him."
- *apeitheō* = refuse belief and obedience to the Son. Inner-being: the disposition of refusal directed at Christ. This is a direct inner-being characteristic statement.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1199-001. CONFIRMED.

**vid=204808 — Act 14:2** | target: `unbelieving`
> "But the unbelieving Jews stirred up the Gentiles and poisoned their minds against the brothers."
- *apeitheō* = unbelieving. The inner state of persistent refusal expressing in hostile action (stirring up, poisoning minds). Inner-being: refusal expressing as interpersonal aggression.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-002. CONFIRMED.

**vid=204809 — Act 19:9** | target: `unbelief`
> "But when some became stubborn and continued in unbelief, speaking evil of the Way before the congregation..."
- *apeitheō* = continued in unbelief/disobedience. Inner-being: stubborn inner persistence in refusal expressing as hostile speech.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1199-002. CONFIRMED.

**vid=45017 — Rom 2:8** | target: `not obey`
> "...for those who are self-seeking and do not obey the truth, but obey unrighteousness, there will be wrath and fury."
- *apeitheō* = not obeying the truth (paired with obeying unrighteousness). Inner-being: refusal of moral truth / active preference for unrighteousness. This is 1199-003 territory.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1199-003. CONFIRMED.

**vid=45013 — Rom 10:21** | target: `disobedient`
> "All day long I have held out my hands to a disobedient and contrary people."
- *apeitheō* = disobedient corporate. The whole covenant people as persistently refusing. Inner-being: corporate covenantal inner refusal.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1199-004. CONFIRMED.

**vid=45014 — Rom 11:30** | target: `disobedient`
> "For just as you were at one time disobedient to God but now have received mercy because of their disobedience,"
- *apeitheō* = prior state of disobedience into which mercy came. Inner-being: the state of covenantal disobedience as the condition mercy is shown into.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1199-005. CONFIRMED.

**vid=45015 — Rom 11:31** | target: `disobedient`
> "...so they too have now been disobedient in order that by the mercy shown to you they also may now receive mercy."
- Same mercy-logic pattern as Rom 11:30. Related to 1199-005.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-005. CONFIRMED.

**vid=45016 — Rom 15:31** | target: `unbelievers`
> "...that I may be delivered from the unbelievers in Judea..."
- *apeitheō* = unbelievers (as noun/descriptor). Paul's concern is deliverance from those who persist in refusal. Inner-being: the inner state of unbelief as characterising a group.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-002. CONFIRMED (hostility/resistance register).

**vid=45012 — Heb 3:18** | target: `disobedient`
> "And to whom did he swear that they would not enter his rest, but to those who were disobedient?"
- *apeitheō* = disobedient wilderness generation. Corporate-historical refusal resulting in exclusion. Inner-being: covenantal inner refusal → 1199-004.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-004. CONFIRMED.

**vid=45011 — Heb 11:31** | target: `disobedient`
> "By faith Rahab the prostitute did not perish with those who were disobedient..."
- *apeitheō* = those who were disobedient (contrasted with Rahab's faith). Corporate-historical disobedience resulting in destruction. Inner-being: covenantal refusal → 1199-004.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-004. CONFIRMED.

**vid=204804 — 1Pe 2:8** | target: `disobey`
> "...They stumble because they disobey the word, as they were destined to do."
- *apeitheō* = disobey the word. The stumbling is the consequence; the disobeying the word is the inner-being characteristic.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-001. CONFIRMED.

**vid=204805 — 1Pe 3:1** | target: `not obey`
> "...even if some do not obey the word, they may be won without a word by the conduct of their wives,"
- *apeitheō* = not obeying the word. Inner-being: refusal of the word in a particular relational context. → 1199-001.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-001. CONFIRMED.

**vid=204806 — 1Pe 3:20** | target: `not obey`
> "...they formerly did not obey, when God's patience waited in the days of Noah..."
- *apeitheō* = historical refusal in the days of Noah (pre-flood generation). Corporate-historical → 1199-004.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-004. CONFIRMED.

**vid=204807 — 1Pe 4:17** | target: `not obey`
> "...what will be the outcome for those who do not obey the gospel of God?"
- *apeitheō* = not obeying the gospel. Refusal of the gospel proclamation → 1199-001 register.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1199-001. CONFIRMED.

**Total: 14 relevant, 0 set aside.**

### Step 3: Grouping review

All 14 verses relevant. Groups hold:
- 1199-001: Joh 3:36, 1Pe 2:8, 1Pe 3:1, 1Pe 4:17 (4 verses)
- 1199-002: Act 14:2, Act 19:9, Rom 15:31 (3 verses)
- 1199-003: Rom 2:8 (1 verse)
- 1199-004: Rom 10:21, Heb 3:18, Heb 11:31, 1Pe 3:20 (4 verses)
- 1199-005: Rom 11:30, Rom 11:31 (2 verses)

**Group count = 5.** The VC instruction notes: "Where 5 or more groups emerge for a single term, pause and assess whether consolidation better serves the criterion before adding further groups." This applies here — but the 5 groups already exist. The question is whether they should remain as is.

**In-session assessment of consolidation:** Each of the 5 groups engages *apeitheō* in a materially different way:
- 1199-001: refusal of divine revelation in Christ/word (christological/soteriological)
- 1199-002: refusal expressing as hostile aggression against gospel-bearers (relational manifestation)
- 1199-003: refusal of moral truth / preference for unrighteousness (ethical dimension)
- 1199-004: corporate covenant-historical disobedience → exclusion/judgement (salvation-history)
- 1199-005: prior disobedience as the condition mercy is shown into (Paul's mercy-logic)

Each is materially different. No consolidation is clearly warranted without Session B analysis of whether the differences matter analytically. The existing 5-group structure is appropriate at VC stage.

### Step 4: Anchor review

- 1199-001: Joh 3:36 (anchor) ✓
- 1199-002: Act 19:9 (anchor) ✓
- 1199-003: Rom 2:8 (anchor) ✓
- 1199-004: Rom 10:21 (anchor) ✓
- 1199-005: Rom 11:30 (anchor) ✓
All 5 groups have anchors. Rule R4 satisfied.

### Step 6: RE-EVALUATION SELF-CHECK

> *"Re-evaluation self-check for G0544 (apeitheō) mti_id=1199:*
> *— Active verses: 14*
> *— Prior classifications reviewed: 14 (every active verse — mandatory)*
> *— Confirmed unchanged: 14*
> *— Revised is_relevant: 0*
> *— Revised group assignment: 0*
> *— Promoted to anchor: 0*
> *— Demoted from anchor: 0*
> *— Check: 14 + 0 + 0 = 14? YES"*

### ORPHAN-GROUP CHECK

> *"Orphan-group check for G0544 mti_id=1199:*
> *— Pre-existing active groups: 5*
> *— Active verse counts: {1199-001: 4, 1199-002: 3, 1199-003: 1, 1199-004: 4, 1199-005: 2}*
> *— Orphan groups: NONE*
> *— Disposition: N/A"*

### TERM 3 SUMMARY

```
Term: G0544 (apeitheō) — to disobey
mti_term_id: 1199
OWNER for: unbelief (registry 165)
Total verses: 14 | Relevant: 14 | Set aside: 0

Groups:
  1199-001 [existing, confirmed]: refusal of Son/word/gospel
    Anchor: Joh 3:36 | Related: 3
  1199-002 [existing, confirmed]: active unbelief as hostility
    Anchor: Act 19:9 | Related: 2
  1199-003 [existing, confirmed]: refusal of moral truth
    Anchor: Rom 2:8 | Related: 0
  1199-004 [existing, confirmed]: corporate covenantal disobedience
    Anchor: Rom 10:21 | Related: 3
  1199-005 [existing, confirmed]: covenantal disobedience as mercy-logic state
    Anchor: Rom 11:30 | Related: 1

Revisions: 0 | Dual-context: 0 | Borderline: 0
Anchor integrity: 5 active anchors across 5 groups ✓

Patch-contribution class: NO-CHANGE
Declared in terms_covered of: VCREVISE (empty-ops)
```

---

## TERM 4: G0570 *apistia* — unbelief | Registry 165 unbelief | mti_id=1198

**Opened:** 2026-04-26  
**md_version:** v2  
**Verses:** 11 active  
**Existing groups:** 1198-001 through 1198-008 (8 groups for 11 verses)

### Step 1: Lexical orientation

*apistia* = unbelief, want of trust and confidence; a state of unbelief, lack of faith; violation of faith, faithlessness. This is a noun naming the inner state itself — not an act of refusal (contrast *apeitheō*). It characterises the person's inner condition (state of faithlessness). 8 groups for 11 verses is a high group-to-verse ratio; the prior re-evaluation at vcb-010 extensively subdivided.

### Step 2: Verse-by-verse filter assessment

**vid=204485 — Mat 13:58** | target: `unbelief`
> "And he did not do many mighty works there, because of their unbelief."
- *apistia* = the inner state of unbelief as limiting factor. Group 1198-001 (corporate covenantal unbelief — local community). Inner-being: the state of unbelief directly.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1198-001. CONFIRMED.

**vid=204483 — Mar 6:6** | target: `unbelief`
> "And he marveled because of their unbelief."
- *apistia* = inner state causing wonder. Related to 1198-001.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1198-001. CONFIRMED.

**vid=204484 — Mar 9:24** | target: `unbelief`
> "Immediately the father of the child cried out and said, 'I believe; help my unbelief!'"
- *apistia* = individual self-acknowledged unbelief co-existing with faith. Classic 1198-002 verse. Inner-being: the tension of faith and unbelief within one person.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-002. CONFIRMED.

**vid=204482 — Mar 16:14** | target: `unbelief`
> "...he rebuked them for their unbelief and hardness of heart, because they had not believed those who saw him after he had risen."
- *apistia* = disciples' post-resurrection unbelief under apostolic rebuke. 1198-003.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-003. CONFIRMED.

**vid=45009 — Rom 3:3** | target: `faithlessness`
> "What if some were unfaithful? Does their faithlessness nullify the faithfulness of God?"
- *apistia* = hypothetical covenantal infidelity used as rhetorical foil. 1198-004.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-004. CONFIRMED.

**vid=45010 — Rom 4:20** | target: `unbelief`
> "No unbelief made him waver concerning the promise of God, but he grew strong in his faith..."
- *apistia* = unbelief in its negated role — the unbelief that did not govern Abraham's response. 1198-005. Inner-being: the inner state named in its absence to magnify faith.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-005. CONFIRMED.

**vid=45007 — Rom 11:20** | target: `unbelief`
> "They were broken off because of their unbelief, but you stand fast through faith."
- *apistia* = corporate covenantal unbelief causing exclusion (branches broken off). 1198-001.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1198-001. CONFIRMED.

**vid=45008 — Rom 11:23** | target: `unbelief`
> "And even they, if they do not continue in their unbelief, will be grafted in..."
- *apistia* = continuing-but-not-permanent unbelief. The condition that may be discontinued. 1198-006. Inner-being: unbelief as a persisting state that holds the door to restoration conditionally open.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-006. CONFIRMED.

**vid=204481 — 1Ti 1:13** | target: `unbelief`
> "...I received mercy because I had acted ignorantly in unbelief,"
- *apistia* = pre-conversion unbelief as the condition in which mercy was given (Paul's autobiography). 1198-007.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-007. CONFIRMED.

**vid=45005 — Heb 3:12** | target: `unbelieving`
> "Take care, brothers, lest there be in any of you an evil, unbelieving heart, leading you to fall away from the living God."
- *apistia* = the heart's susceptibility to an unbelieving condition → apostasy trajectory. 1198-008. Inner-being: the heart as the location of the unbelieving orientation and warning against it.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-008. CONFIRMED.

**vid=45006 — Heb 3:19** | target: `unbelief`
> "So we see that they were unable to enter because of unbelief."
- *apistia* = unbelief as the cause of wilderness exclusion. 1198-001 (corporate covenantal — wilderness generation). Anchor of 1198-001.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1198-001. CONFIRMED.

**Total: 11 relevant, 0 set aside.**

### Step 3: Grouping assessment — 8 groups for 11 verses

High group count warrants review. Verse distribution:
- 1198-001: Mat 13:58, Mar 6:6, Rom 11:20, Heb 3:19 (4 verses)
- 1198-002: Mar 9:24 (1 verse)
- 1198-003: Mar 16:14 (1 verse)
- 1198-004: Rom 3:3 (1 verse)
- 1198-005: Rom 4:20 (1 verse)
- 1198-006: Rom 11:23 (1 verse)
- 1198-007: 1Ti 1:13 (1 verse)
- 1198-008: Heb 3:12 (1 verse)

7 of 8 groups have only 1 verse each. This is an artifact of the extensive vcb-010 subdivision. **Question for in-session assessment:** Is this level of subdivision warranted at VC stage, or has the classification over-subdivided?

**In-session resolution by reading the groups and their verses:**

The instruction states: "A new group is warranted when the inner-being characteristic being engaged is materially different from all existing groups, or when the same characteristic is engaged in a materially different way." And: "Minor variations in emphasis or tone within the same essential characteristic engagement do not warrant a new group."

Reviewing each single-verse group against the characteristic-perspective model:
- 1198-002 (individual self-acknowledged co-existing unbelief / Mar 9:24): Materially different from corporate unbelief — the inner tension within faith is a distinct characteristic engagement. ✓ Warranted.
- 1198-003 (disciples' post-resurrection unbelief under rebuke / Mar 16:14): The characteristic is still unbelief — but the context (post-resurrection, apostolic formation) is different. Is the *characteristic* different? The verse engages unbelief + hardness of heart in apostolic witnesses. The hardness-of-heart dimension (carried by *sklērokardia* in the same verse) adds texture — but *apistia* here still names the unbelief state. Could this be 1198-001 (corporate unbelief)? The disciples as a group did fail — but the context of being the appointed witnesses under rebuke is distinctive. Borderline — but the prior classification is defensible and not clearly wrong. RETAIN.
- 1198-004 (hypothetical infidelity as rhetorical foil / Rom 3:3): The characteristic is *faithlessness* in a purely rhetorical frame — not actual unbelief but its invocation as argument. Materially different in register (rhetorical foil vs actual state). ✓ Warranted.
- 1198-005 (negated unbelief — Abraham / Rom 4:20): *apistia* named in its absence. Unique — the term's function is to mark what Abraham's faith was not. Materially different in how the characteristic is engaged. ✓ Warranted.
- 1198-006 (continuing-but-not-permanent / Rom 11:23): The conditionality dimension ("if they do not continue in their unbelief") distinguishes this from 1198-001's exclusion. The restoration possibility is the material difference. ✓ Warranted.
- 1198-007 (autobiographical pre-conversion / 1Ti 1:13): Context of Paul's own testimony. Unbelief as the ground for received mercy. Is this materially different from 1198-001? The autobiographical individual-testimony register differs from corporate covenantal exclusion. ✓ Warranted (individual testimony vs corporate judgement).
- 1198-008 (heart susceptibility leading to apostasy / Heb 3:12): The inner-being characteristic is the susceptibility of the heart to slide into unbelief. The forward-looking warning dimension differs from backward-looking exclusion (1198-001). ✓ Warranted — the directive-warning engagement is distinct.

**Conclusion:** All 8 groups are warranted at VC stage, though single-verse groups may warrant consolidation in Session B analysis when the analytical purpose is clearer. No revision needed here.

### Step 4: Anchor review

- 1198-001: Heb 3:19 (anchor) ✓
- 1198-002: Mar 9:24 (anchor) ✓
- 1198-003: Mar 16:14 (anchor, sole verse) ✓
- 1198-004: Rom 3:3 (anchor, sole verse) ✓
- 1198-005: Rom 4:20 (anchor, sole verse) ✓
- 1198-006: Rom 11:23 (anchor, sole verse) ✓
- 1198-007: 1Ti 1:13 (anchor, sole verse) ✓
- 1198-008: Heb 3:12 (anchor, sole verse) ✓
All 8 groups have anchors. Rule R4 satisfied.

### Step 6: RE-EVALUATION SELF-CHECK

> *"Re-evaluation self-check for G0570 (apistia) mti_id=1198:*
> *— Active verses: 11*
> *— Prior classifications reviewed: 11 (every active verse — mandatory)*
> *— Confirmed unchanged: 11*
> *— Revised is_relevant: 0*
> *— Revised group assignment: 0*
> *— Promoted to anchor: 0*
> *— Demoted from anchor: 0*
> *— Check: 11 + 0 + 0 = 11? YES"*

### ORPHAN-GROUP CHECK

> *"Orphan-group check for G0570 mti_id=1198:*
> *— Pre-existing active groups: 8*
> *— Active verse counts: {1198-001: 4, 1198-002: 1, 1198-003: 1, 1198-004: 1, 1198-005: 1, 1198-006: 1, 1198-007: 1, 1198-008: 1}*
> *— Orphan groups: NONE*
> *— Disposition: N/A"*

**Session B observation (flagged for VCSBFLAGS):** The high group count (8 groups / 11 verses) with 7 single-verse groups merits Session B attention on whether the fine-grained grouping reflects meaningful analytical distinctions or represents over-subdivision that will need consolidation at analysis stage. Flagged as SBF-VCB-Q01-001.

### TERM 4 SUMMARY

```
Term: G0570 (apistia) — unbelief
mti_term_id: 1198
OWNER for: unbelief (registry 165)
Total verses: 11 | Relevant: 11 | Set aside: 0

Groups: 8 (all confirmed, no changes)
  1198-001: corporate covenantal unbelief — anchor Heb 3:19, related: 3
  1198-002: individual self-acknowledged co-existing unbelief — anchor Mar 9:24
  1198-003: apostolic-formation rebuke — anchor Mar 16:14
  1198-004: rhetorical foil — anchor Rom 3:3
  1198-005: negated unbelief / Abraham — anchor Rom 4:20
  1198-006: continuing-but-not-permanent — anchor Rom 11:23
  1198-007: autobiographical pre-conversion — anchor 1Ti 1:13
  1198-008: heart-susceptibility / directive warning — anchor Heb 3:12

Revisions: 0 | Dual-context: 0 | Borderline: 0
Anchor integrity: 8 active anchors across 8 groups ✓

Patch-contribution class: NO-CHANGE
Declared in terms_covered of: VCREVISE (empty-ops)

SB FLAG raised: SBF-VCB-Q01-001 — high group count (8/11 verses) warrants Session B consolidation assessment.
```

---

## TERM 5: G4710 *spoudē* — diligence | Registry 181 zeal | mti_id=1268

**Opened:** 2026-04-26  
**md_version:** v2  
**Verses:** 12 active  
**Existing groups:** 1268-001 through 1268-011 (11 groups for 12 verses)

### Step 1: Lexical orientation

*spoudē* spans: haste (physical); earnestness; diligence; zeal; eagerness. The physical-haste sense appears in narrative contexts; the earnestness/zeal sense dominates the Pauline and epistolary corpus. 11 groups for 12 verses is an exceptionally high ratio — needs careful assessment.

### Step 2: Verse-by-verse filter assessment

**vid=215267 — Mar 6:25** | target: `haste`
> "And she came in immediately with haste to the king and asked, saying, 'I want you to give me at once the head of John the Baptist on a platter.'"
- *spoudē* = physical haste. But what is the inner-being connection? The prior group (1268-001) says: "Term names physical haste expressing negative-moral inner urgency — the haste of compliance with a murderous demand." The haste reveals an inner disposition of urgency driven by the desire to secure the execution. §3.4 (expressions as inner-being evidence) applies — the physical haste expresses an inner urgency/disposition.
- **Assessment:** The inner state is arguably better described as moral urgency or desire-compliance — but is the inner-being content carried by *spoudē* or by the request itself ("I want you to give me")? *Spoudē* names the manner (haste), not the desire. However, the haste as manner does disclose something about the inner orientation — the eagerness, the single-minded compliance. This is borderline.
- **In-session resolution:** The prior group description specifically anchors this as an expression of inner urgency, which follows §3.4. The haste is not purely mechanical (a trained reflex); it reflects the inner disposition of eager compliance with a demand. The classification is defensible under §3.4.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-001. CONFIRMED.

**vid=215266 — Luk 1:39** | target: `haste`
> "In those days Mary arose and went with haste into the hill country, to a town in Judah,"
- *spoudē* = physical haste after divine revelation (the Annunciation). Prior group (1268-002): "positive-obedient inner eagerness — the haste of joyful response after divine revelation."
- **Assessment:** Similar borderline as Mar 6:25. The haste follows the angel's message — it expresses Mary's eager response/obedience/joy. The inner state is the disposition of eager obedience.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-002. CONFIRMED.

**vid=49700 — Rom 12:8** | target: `zeal`
> "...the one who leads, with zeal..."
- *spoudē* = zeal as the manner of leadership in body-life. Inner-being: the disposition of zeal appropriate to leadership.
- **Filter decision:** RELEVANT. Prior: relevant · related · group=1268-004. CONFIRMED.

**vid=49699 — Rom 12:11** | target: `zeal`
> "Do not be slothful in zeal, be fervent in spirit, serve the Lord."
- *spoudē* = zeal contrasted with sloth; paired with fervency of spirit. Direct inner-being statement. Anchor of 1268-004.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-004. CONFIRMED.

**vid=49692 — 2Cor 7:11** | target: `earnestness`
> "For see what earnestness this godly grief has produced in you..."
- *spoudē* = the earnestness produced by godly grief / repentance. Inner-being: the disposition arising from genuine repentance.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-005. CONFIRMED.

**vid=49693 — 2Cor 7:12** | target: `earnestness`
> "...in order that your earnestness for us might be revealed to you in the sight of God."
- *spoudē* = earnestness revealed under disciplinary writing. Inner-being: relational disposition disclosed.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-006. CONFIRMED.

**vid=49695 — 2Cor 8:7** | target: `earnestness`
> "But as you excel in everything — in faith, in speech, in knowledge, in all earnestness, and in our love for you..."
- *spoudē* = earnestness as one virtue in a catalogue of excellences. Inner-being: disposition listed alongside faith and love.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-007. CONFIRMED.

**vid=49696 — 2Cor 8:8** | target: `earnestness`
> "...to prove by the earnestness of others that your love also is genuine."
- *spoudē* = earnestness as evidence/proof of genuine love. Inner-being: the dispositional quality that authenticates love.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-008. CONFIRMED.

**vid=49694 — 2Cor 8:16** | target: `earnest care`
> "But thanks be to God, who put into the heart of Titus the same earnest care I have for you."
- *spoudē* = earnest care as a God-given inner disposition placed in the heart. Strongly inner-being: the disposition as heart-implanted.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-009. CONFIRMED.

**vid=49697 — Heb 6:11** | target: `earnestness`
> "And we desire each one of you to show the same earnestness to have the full assurance of hope until the end,"
- *spoudē* = earnestness oriented toward eschatological assurance. Inner-being: the disposition pursuing assurance of hope.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-010. CONFIRMED.

**vid=215265 — 2Pe 1:5** | target: `effort`
> "For this very reason, make every effort to supplement your faith with virtue, and virtue with knowledge,"
- *spoudē* = inner effort / moral-formative supplementation. Inner-being: the disposition of diligent supplementation of faith.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-011. CONFIRMED.

**vid=49698 — Jude 3** | target: `eager`
> "Beloved, although I was very eager to write to you about our common salvation, I found it necessary to write appealing to you to contend for the faith..."
- *spoudē* = the author's inner eagerness / writing-urgency. Inner-being: the epistolary disposition disclosed autobiographically. Anchor of 1268-003.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=1268-003. CONFIRMED.

**Total: 12 relevant, 0 set aside.**

### Step 3: Grouping assessment — 11 groups for 12 verses

Same concern as G0570. 10 of 11 groups have only 1 verse each.

**In-session assessment of 11-group structure:**

The instruction's criterion: "A new group is warranted when the inner-being characteristic being engaged is materially different from all existing groups, or when the same characteristic is engaged in a materially different way."

The characteristic throughout is `earnestness/zeal/eager disposition`. What varies is:
- Direction (toward whom / what)
- Register (physical haste vs inner zeal)
- Source (God-given vs self-directed vs produced by grief)
- Context (body-life, eschatological, relational, epistolary)

**Is any of this material enough to warrant separate groups at VC stage?**

Groups 1268-001 and 1268-002 (physical haste): The distinction (negative-moral vs positive-obedient) is real — they represent opposite moral registers of the same physical expression. Defensible as separate.

Groups 1268-003 through 1268-011 (earnestness/zeal in various Pauline contexts): The variation here is primarily contextual — the characteristic being engaged (earnest disposition/zeal) is essentially the same across most of these groups. The differences are:
- 1268-004 (body-life zeal) vs 1268-005 (fruit of repentance) vs 1268-006 (relational earnestness) vs 1268-007 (listed virtue) vs 1268-008 (evidence of love) vs 1268-009 (God-given) vs 1268-010 (eschatological) vs 1268-011 (moral-formative)

These are primarily *contextual variations* of the same characteristic (earnest disposition). Some of these could be consolidated without losing analytical precision. However, this judgment is at the edge of VC competence — consolidation involves deciding what the characteristic-perspective grouping *should* capture, which properly belongs to Session B analysis.

**In-session resolution per §6.5.0:** The question of whether over-subdivision occurred is a classifier-resolvable question only partially — it requires examining whether a Session B analyst would find meaningful difference between, say, "earnestness as fruit of repentance" (1268-005) and "earnestness as relational disposition under disciplinary writing" (1268-006). This judgment requires Session B analytical context.

**Decision:** Retain all 11 groups as is. Flag for Session B that the high group count and near-exclusive single-verse pattern warrants consolidation assessment. The prior vcb-010 classification was thorough; no revision is clearly warranted under re-evaluation.

### Step 4: Anchor review

All 11 groups have 1 anchor each. Rule R4 satisfied.

### Step 6: RE-EVALUATION SELF-CHECK

> *"Re-evaluation self-check for G4710 (spoudē) mti_id=1268:*
> *— Active verses: 12*
> *— Prior classifications reviewed: 12 (every active verse — mandatory)*
> *— Confirmed unchanged: 12*
> *— Revised is_relevant: 0*
> *— Revised group assignment: 0*
> *— Promoted to anchor: 0*
> *— Demoted from anchor: 0*
> *— Check: 12 + 0 + 0 = 12? YES"*

### ORPHAN-GROUP CHECK

> *"Orphan-group check for G4710 mti_id=1268:*
> *— Pre-existing active groups: 11*
> *— Active verse counts: {1268-001:1, 1268-002:1, 1268-003:1, 1268-004:2, 1268-005:1, 1268-006:1, 1268-007:1, 1268-008:1, 1268-009:1, 1268-010:1, 1268-011:1}*
> *— Orphan groups: NONE*
> *— Disposition: N/A"*

**Session B observation (flagged for VCSBFLAGS):** 11 groups for 12 verses with 10 single-verse groups. The Pauline earnestness/zeal groups (1268-004 through 1268-011) may over-subdivide a single characteristic across contextual variations. Session B should assess whether consolidation into 3-4 groups (physical haste / inner zeal in body-life / earnestness in relational contexts / eschatological/formative disposition) better serves the characteristic-perspective model. Flagged as SBF-VCB-Q01-002.

### TERM 5 SUMMARY

```
Term: G4710 (spoudē) — diligence
mti_term_id: 1268
OWNER for: zeal (registry 181)
Total verses: 12 | Relevant: 12 | Set aside: 0

Groups: 11 (all confirmed, no changes)
  1268-001 through 1268-011 — see group table in Session A
  All anchors confirmed. Rule R4 satisfied.

Revisions: 0 | Dual-context: 0 | Borderline: 0
Anchor integrity: 11 active anchors across 11 groups ✓

Patch-contribution class: NO-CHANGE
Declared in terms_covered of: VCREVISE (empty-ops)

SB FLAG raised: SBF-VCB-Q01-002 — 11 groups / 12 verses: Pauline groups may over-subdivide single characteristic.
```

---

## TERM 6: G3878 *parakouō* — to ignore | Registry 050 disobedience | mti_id=5111

**Opened:** 2026-04-26  
**md_version:** v2  
**Verses:** 2 active  
**Existing groups:** 5111-001 (wilful refusal to hear)

### Step 1: Lexical orientation

*parakouō* = to refuse to listen, ignore; to overhear; to fail to listen; refuse to listen; neglect to obey; disregard. The Mk 5:36 use = sensory overhearing (incidental). The Mt 18:17 use = wilful refusal to hear the community's voice. The term has 7 total occurrences but only 2 in the confirmed verse set (VERSE_EVIDENCE_CONCENTRATED).

### Step 2: Verse-by-verse filter assessment

**vid=155906 — Mat 18:17** | target: `listen`
> "If he refuses to listen to them, tell it to the church. And if he refuses to listen even to the church, let him be to you as a Gentile and a tax collector."
- *parakouō* used twice here (target = `listen` — both `refuses to listen` instances). The term names the wilful refusal to hear the community's corrective voice. Inner-being: the inner orientation of closed attention, the disposition of refusal directed at the community's authority.
- Prior group 5111-001: "Term names the wilful refusal to hear — the inner orientation of closed attention or contempt expressed through the repeated failure to receive the voice of the community." This is characteristic-perspective: characteristic = wilful inner closure; term = its expression.
- **Filter decision:** RELEVANT. Prior: relevant · anchor · group=5111-001. CONFIRMED.

**vid=155905 — Mar 5:36** | target: `overhearing`
> "But overhearing what they said, Jesus said to the ruler of the synagogue, 'Do not fear, only believe.'"
- *parakouō* = sensory overhearing (Jesus overheard the message). The inner-being content in the verse (fear/phobeo, believe/pisteuo) is carried by those terms, not by *parakouō*. *parakouō* here is a purely sensory/perceptual act.
- Prior: set aside — wrong_face. Notes: "wrong_face: inner-being content carried by phobeo (fear) and pisteuo (believe), not by parakouo."
- **Assessment:** Confirmed. *parakouō* in Mar 5:36 = incidental overhearing with no inner-being engagement by the term itself. The inner-being content (fear and faith) is carried by *phobeo* and *pisteuo*.
- **Filter decision:** SET ASIDE (wrong_face). Prior classification confirmed. CONFIRMED.

### Step 3: Grouping review

- **5111-001:** Mat 18:17 (1 verse, anchor). Group confirmed.
- No other groups needed.

### Step 4: Anchor review

- 5111-001: Mat 18:17 (anchor). Group has 1 anchor. Rule R4 satisfied.

### Step 6: RE-EVALUATION SELF-CHECK

> *"Re-evaluation self-check for G3878 (parakouō) mti_id=5111:*
> *— Active verses: 2*
> *— Prior classifications reviewed: 2 (every active verse — mandatory)*
> *— Confirmed unchanged: 2 (Mat 18:17 anchor confirmed; Mar 5:36 set-aside confirmed)*
> *— Revised is_relevant: 0*
> *— Revised group assignment: 0*
> *— Promoted to anchor: 0*
> *— Demoted from anchor: 0*
> *— Check: 2 + 0 + 0 = 2? YES"*

### ORPHAN-GROUP CHECK

> *"Orphan-group check for G3878 mti_id=5111:*
> *— Pre-existing active groups: 1*
> *— Active verse counts: {5111-001: 1}*
> *— Orphan groups: NONE*
> *— Disposition: N/A"*

### TERM 6 SUMMARY

```
Term: G3878 (parakouō) — to ignore
mti_term_id: 5111
OWNER for: disobedience (registry 050)
Total verses: 2 | Relevant: 1 | Set aside: 1

Groups:
  5111-001 [existing, confirmed]: "Term names the wilful refusal to hear — the inner orientation of closed attention or contempt expressed through the repeated failure to receive the voice of the community"
    Anchor: Mat 18:17 (vid=155906)
    Related: 0

Set asides:
  Mar 5:36 (vid=155905) — wrong_face: inner-being content carried by phobeo (fear) and pisteuo (believe)

Revisions: 0 | Dual-context: 0 | Borderline: 0
Anchor integrity: 1 active anchor ✓

Patch-contribution class: NO-CHANGE
Declared in terms_covered of: VCREVISE (empty-ops)
```

---

## END-OF-SESSION REVIEW

### All-terms summary

| mti_id | Term | Verses | Relevant | Set aside | Groups | Patch class |
|---|---|---|---|---|---|---|
| 1562 | G3948 paroxusmos | 2 | 2 | 0 | 2 | NO-CHANGE |
| 937 | H6293 pa.ga | 43 | 11 | 32 | 2 | NO-CHANGE |
| 1199 | G0544 apeitheō | 14 | 14 | 0 | 5 | NO-CHANGE |
| 1198 | G0570 apistia | 11 | 11 | 0 | 8 | NO-CHANGE |
| 1268 | G4710 spoudē | 12 | 12 | 0 | 11 | NO-CHANGE |
| 5111 | G3878 parakouō | 2 | 1 | 1 | 1 | NO-CHANGE |

**All 6 terms: NO-CHANGE (RE-EVALUATION — no revisions warranted)**

**Patch routing decision:** Single VCREVISE with empty-ops for all 6 terms. All declared in `terms_covered` + `input_versions`. Plus one VCSBFLAGS patch (2 SB observations).

---

## DEFERRED FLAGS / SESSION B FLAGS

### SBF-VCB-Q01-001 — G0570 apistia mti_id=1198 — Registry 165 unbelief
**Source:** In-session observation during Term 4 review  
**Finding:** 8 groups for 11 verses; 7 groups have only 1 verse each. The fine-grained grouping from vcb-010 creates many single-verse groups. While each group is analytically defensible, Session B should assess whether the distinctions are analytically operational or whether consolidation (e.g., corporate unbelief / individual unbelief / rhetorical/negated uses) better serves the characteristic-perspective model at analysis stage.  
**Session target:** Session B (Registry 165 unbelief)  
**Action required at patch stage:** VCSBFLAGS insert for this observation.

### SBF-VCB-Q01-002 — G4710 spoudē mti_id=1268 — Registry 181 zeal
**Source:** In-session observation during Term 5 review  
**Finding:** 11 groups for 12 verses; 10 groups have only 1 verse each. The Pauline earnestness groups (1268-004 through 1268-011) appear to subdivide contextual variations of a single characteristic (earnest disposition). Session B should assess whether groups 1268-005 through 1268-011 represent meaningfully distinct inner-being characteristics or whether they subdivide by Pauline rhetorical context rather than by the characteristic engaged.  
**Session target:** Session B (Registry 181 zeal)  
**Action required at patch stage:** VCSBFLAGS insert for this observation.

---

## ANOMALY RECORD

**ANOM-001 — G3948 vc_status inconsistency**  
Term G3948 (paroxusmos) mti_id=1562 has `vc_status = not_done` but has 2 existing verse_context rows and 2 active groups. This is an internal inconsistency — the classification work was done but the status was not advanced. The empty-ops VCREVISE including this term in `terms_covered` will trigger the applicator to write `vc_status = vc_completed`, resolving the inconsistency.

---

## PATCH ROUTING FINAL DECLARATION

**Term G3948** mti_id=1562: patch-contribution class = NO-CHANGE. Declared in terms_covered of: VCREVISE.  
**Term H6293** mti_id=937: patch-contribution class = NO-CHANGE. Declared in terms_covered of: VCREVISE.  
**Term G0544** mti_id=1199: patch-contribution class = NO-CHANGE. Declared in terms_covered of: VCREVISE.  
**Term G0570** mti_id=1198: patch-contribution class = NO-CHANGE. Declared in terms_covered of: VCREVISE.  
**Term G4710** mti_id=1268: patch-contribution class = NO-CHANGE. Declared in terms_covered of: VCREVISE.  
**Term G3878** mti_id=5111: patch-contribution class = NO-CHANGE. Declared in terms_covered of: VCREVISE.

**Patches to produce:**  
1. VCREVISE (empty-ops) — all 6 terms  
2. VCSBFLAGS — 2 observations (SBF-VCB-Q01-001 and SBF-VCB-Q01-002)

---

*Obslog v1 — written 2026-04-26 — VCB-Q01 vc-review*  
*Next action: produce VCREVISE patch + VCSBFLAGS patch*

---

## PATCH PRODUCTION — 2026-04-26

### Pre-submission self-check results

```
Patch self-check PATCH-20260426-VCBQ01-VCREVISE-V1: PASS
  - top-level keys: PASS
  - _patch_meta completeness: PASS
  - patch_type VCREVISE: PASS
  - session_b_status null: PASS
  - operations list empty (no-change): PASS
  - total_operations == 0: PASS
  - terms_covered 6 terms: PASS
  - input_versions covers all terms_covered: PASS
  - A-03 version values match Session A md_versions: PASS

Patch self-check PATCH-20260426-VCBQ01-VCSBFLAGS-V1: PASS
  - top-level keys: PASS
  - _patch_meta completeness: PASS
  - patch_type VCSBFLAGS: PASS
  - session_b_status null: PASS
  - all ops = insert on wa_session_research_flags: PASS
  - all records session_target = 'Session B': PASS
  - all flag_codes in allowed list: PASS
  - all required record fields present: PASS
  - resolved = 0 on all: PASS
  - input_versions absent (not required): PASS
  - total_operations == 2: PASS
```

### Patches produced

| Filename | patch_id | Type | Ops |
|---|---|---|---|
| wa-vcbq01-patch-vcrevise-v1-20260426.json | PATCH-20260426-VCBQ01-VCREVISE-V1 | VCREVISE | 0 (empty-ops) |
| wa-vcbq01-patch-vcsbflags-v1-20260426.json | PATCH-20260426-VCBQ01-VCSBFLAGS-V1 | VCSBFLAGS | 2 |

Both patches dual-written to /home/claude/ and /mnt/user-data/outputs/. Self-check: PASS on both.

### Expected applicator confirmation — VCREVISE

After Claude Code applies PATCH-20260426-VCBQ01-VCREVISE-V1, expected confirmation:

```sql
SELECT mt.id, mt.strongs_number, mt.vc_status, mt.md_version
FROM mti_terms mt
WHERE mt.id IN (1562, 937, 1199, 1198, 1268, 5111);
```

Expected: all 6 rows show `vc_status = 'vc_completed'`; md_version bumped by 1 from pre-patch value.

Special check for G3948 (mti_id=1562): was `not_done` → must now be `vc_completed`.

```sql
SELECT wr.no, wr.word, wr.verse_context_status
FROM word_registry wr
WHERE wr.no IN (4, 94, 165, 181, 50);
```

Expected: registries where all OWNER + XREF-via-OWNER terms are now at vc_completed will advance to `verse_context_status = 'Complete'`.

### Expected applicator confirmation — VCSBFLAGS

After Claude Code applies PATCH-20260426-VCBQ01-VCSBFLAGS-V1:

```sql
SELECT flag_label, flag_code, registry_id, strongs_reference, session_target
FROM wa_session_research_flags
WHERE flag_label IN ('SBF-VCB-Q01-001', 'SBF-VCB-Q01-002');
```

Expected: 2 rows returned, one per registry (165, 181), both with `session_target = 'Session B'`, `resolved = 0`.

