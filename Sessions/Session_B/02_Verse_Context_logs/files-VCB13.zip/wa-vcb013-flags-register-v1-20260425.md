# VCB-013 — Flags Register

**Session:** VCB-013 (Verse Context re-evaluation, 15-term batch)
**Governing instruction:** wa-versecontext-instruction-v3_9-20260425.md
**Companion patch instruction:** wa-patch-instruction-v2_9-20260425.md
**Produced:** 2026-04-25

This register lists all flags raised during VCB-013, organised by class. Researcher resolution decisions can be recorded inline.

---

## 1. Halt-class flags (partial-completion anomalies)

These three flags trigger an immediate halt for the affected term per VC §6.2 Step 2. The terms are excluded from VCB-013's patches and remain at `vc_status = not_done`.

### DF-002 — H2896A *tov* (mti=884, registry 067 goodness)
- **Active verses:** 306
- **Active verse_context rows:** 165
- **Pending:** 141
- **Existing groups:** 6 (884-001 through 884-006)
- **Apparent cause (inferential):** Pre-M39 implicit set-aside model — prior session classified the inner-being-relevant subset and did not write rows for the physical/spatial/numerical uses. Under v3_5 §3.2b, absence of a row means pending, not set-aside.
- **Disposition this session:** EXCLUDED. Patch consequence: no operations on mti=884; `vc_status` stays `not_done`; registry 067 cannot advance to Complete.
- **Researcher decision required:**
  - (A) How to resolve — dedicated session to classify the 141 pending verses, or full re-classification of the term.
  - (B) Confirm exclusion from VCB-013.
- **Researcher resolution:** [PENDING]

### DF-004 — H8549G *ta.mim* (mti=934, registry 092 integrity)
- **Active verses:** 51
- **Active verse_context rows:** 6
- **Pending:** 45
- **Existing groups:** 2 (934-001 God's perfect way; 934-002 perfect Torah)
- **Apparent cause (inferential):** Pre-M39 implicit set-aside of sacrificial-physical *ta.mim* verses (Exo, Lev, Num "without blemish" offerings — `physical_only` candidates). The 6 classified verses are the inner-being-relevant uses (Psa 19:7, Deu 32:4, Job 37:16, etc.).
- **Disposition this session:** EXCLUDED.
- **Researcher decision required:** Same as DF-002. The 45 pending verses are likely a clean batch of `physical_only` set-asides, mechanically tractable in a follow-on session.
- **Researcher resolution:** [PENDING]

### DF-006 — H2181 *za.nah* (mti=1221, registry 171 whoredom)
- **Active verses:** 83
- **Active verse_context rows:** 71
- **Pending:** 12 (mostly Pentateuchal: Gen 34:31, Gen 38:15, Gen 38:24, Exo 34:15-16, Lev 17:7, 19:29, 20:5-6, 21:7, 21:9, 21:14, Num 15:39, Num 25:1, Deu 22:21)
- **Existing groups:** [count not inspected — halt before §6.2 Step 3]
- **Apparent cause (inferential):** Mixed — some verses are figurative-spiritual whoredom that should retain (Lev 17:7 "they shall no more sacrifice ... after whom they whore"; Lev 20:5; Num 15:39 "after which you whore"); others may be `no_inner_being` or `physical_only`. Not a uniform set-aside batch. Genuine classification work required.
- **Disposition this session:** EXCLUDED.
- **Researcher decision required:** Schedule a dedicated re-classification session for the 12 pending verses.
- **Researcher resolution:** [PENDING]

---

## 2. Small-gap halt with researcher override option

### DF-005 — G1258 *dialektos* (mti=6065, registry 127 reasoning)
- **Active verses:** 6
- **Active verse_context rows:** 5
- **Pending:** 1 — Acts 1:19 (vid=187509)
- **Existing groups:** 1 (6065-001)
- **Apparent cause:** The unclassified verse uses *dialektos* etymologically ("the field was called in their own language Akeldama") — `no_inner_being` set-aside, unambiguous.
- **Options:**
  - (A) Treat as halt; exclude from VCB-013; schedule for follow-up.
  - (B) **Resolve in VCB-013** — single-verse insert (`set_aside_reason='no_inner_being'`); term re-classed as MIXED → packaged in legacy VERSECONTEXT patch per VC §6.3 Step 3. Operationally clean; the classification of Acts 1:19 is uncontroversial.
- **Claude AI lean:** Option B (resolve in session).
- **Working decision:** Option B accepted. See `wa-vcb013-patch-versecontext-v1-20260425.json`.
- **Researcher resolution:** [PROCEED WITH OPTION B / OVERRIDE TO A]

---

## 3. Description-amendment flags

### DF-001 — G5544 *chrēstotēs* (mti=886, registry 067 goodness)
- **Verse:** Rom 3:12 (vid=24752) — "no one does **good** [chrēstotēs], not even one" (universal-depravity catena, Ps 14:3 LXX)
- **Issue:** Prior classification places verse in 886-002 (Spirit-produced quality of the believer); the verse engages the human-side characteristic of kindness/goodness *by negation*. Group description does not strictly cover the negation register.
- **Options:**
  - (A) No change — verse stays in 886-002 unannotated. Classification incorrect/under-specified.
  - (B) New group 886-003 for the negation register. Single-verse group → fragmentation risk against §6.2 grouping criterion.
  - (C) **Notes-only revision** on vid=24752 — verse stays in 886-002, notes field set: "negation register — quotes Ps 14:3 LXX universal depravity; chrēstotēs named by absence in the fallen inner being". Group description unchanged.
- **Claude AI lean:** Option C.
- **Working decision:** Option C applied (see VCREVISE OP-003).
- **Researcher resolution:** [PROCEED WITH OPTION C / OVERRIDE]

### DF-003 — G2168 *eucharisteō* (mti=5480, registry 069 gratitude)
- **Verses at edge:** Rom 16:4 (Paul thanks Priscilla and Aquila — humans, not God); Lk 18:11 (Pharisee's distorted self-righteous "thank you")
- **Issue:** Existing group description "giving thanks to God ... absence ... corruption" doesn't strictly cover thanks-to-humans (Rom 16:4) or distortion-as-distinct-from-absence (Lk 18:11).
- **Options:**
  - (A) No change. Description undersells the corpus.
  - (B) **Group description amendment.** Revised text: *"Term names the act and habitual inner posture of giving thanks — primarily to God in response to grace received, but extending to relational gratitude rendered in recognition of God's work through others — the reorientation of the inner being toward gratitude, the absence or distortion of which marks the corruption of the inner person, and the presence of which sanctifies all conduct and circumstances"*
  - (C) Split into multiple groups (5480-001 thanks to God; 5480-002 thanks to humans; 5480-003 distorted thanks). Fragmentation against §6.2.
- **Claude AI lean:** Option B.
- **Working decision:** Option B applied (see VCREVISE OP-001).
- **Researcher resolution:** [PROCEED WITH OPTION B / OVERRIDE]

### DF-007 — H2183 *ze.nu.nim* (mti=1220, registry 171 whoredom)
- **Verses at edge:** Gen 38:24 (Tamar — narrative); 2 Ki 9:22 (Jezebel — individual figure); Nah 3:4 (Nineveh — pagan nation)
- **Issue:** Existing group description "leading **Israel** astray" is narrower than the actual corpus, which includes individual figures and foreign nations.
- **Options:**
  - (A) No change.
  - (B) **Group description amendment.** Revised text: *"Whoredom as a spiritual / inner-being condition — the spirit of whoredom within that orients people away from God toward idolatry, defilement, and alliance with what corrupts; named figuratively of Israel, of individuals, and of foreign nations alike"*
- **Claude AI lean:** Option B.
- **Working decision:** Option B applied (see VCREVISE OP-002).
- **Researcher resolution:** [PROCEED WITH OPTION B / OVERRIDE]

---

## 4. Soft observations (no action this session)

### OBS-VC-001 — Self-check arithmetic gap (instruction-level)
The v3_9 §6.2 Step 6 self-check arithmetic has buckets {Confirmed unchanged, Revised is_relevant, Revised group, Promoted, Demoted}. A notes-only revision on a verse_context row (where is_relevant + group + is_anchor are all unchanged but notes are added — as in DF-001 Option C on vid=24752) does not fit any bucket. Strict template gives 6 + 0 + 0 = 6 ≠ 7 active verses for G5544. Recommendation: future instruction revision could add a "notes-only revision" bucket. Not blocking VCB-013.

### OBS-VC-002 — G0861 anchor redundancy
Group 935-001's two anchors are 1 Cor 15:42 and 1 Cor 15:53 — both express the same aspect (perishable→imperishable resurrection transformation). §4 says two anchors should represent distinct aspects. Could reduce to a single anchor without analytical loss. Not actioned this session.

### OBS-VC-003 — G1261 Lk 2:35 boundary
Lk 2:35 ("thoughts from many hearts may be revealed") sits at the boundary between groups 1081-001 (heart-source corruption) and 1081-002 (cognitive deliberation). Prior assignment to 1081-002 is defensible; a 1081-001 reading is also defensible. Not actioned. Note for Session B awareness.

---

## 5. Session B observation flags (carried forward via VCSBFLAGS patch)

### SBF-VCB013-001 — chrēstotēs tripartite engagement pattern
G5544 across 7 verses shows presence (renewed quality, Spirit-fruit, divine attribute), absence (Rom 3:12 Ps-14 quotation), distortion (not strong here, but cross-reference SBF-VCB013-002). Worth examining in Session B whether this presence/absence pole is a structural feature of moral-quality vocabulary in registry 067 broadly. **Inserted via VCSBFLAGS patch.**

### SBF-VCB013-002 — eucharisteō tripartite engagement pattern
G2168 across 38 verses shows presence (sanctifies — 1 Th 5:18, Eph 5:20), absence (Rom 1:21 corruption), distortion (Lk 18:11 Pharisee). Pattern may extend across the EUCHARIST family (G2168/G2169/G2170) and habitual-disposition vocabulary in gratitude / praise / faith registries. **Inserted via VCSBFLAGS patch.**

---

## 6. Programme-pattern observation

### PPO-VCB013-001 — Hebrew large-corpus partial-completion pattern
Three of four Hebrew terms in this batch (H2896A *tov* 141 pending; H8549G *ta.mim* 45 pending; H2181 *za.nah* 12 pending) and one Greek term with a small gap (G1258 *dialektos* 1 pending) exhibit partial-completion anomalies. The recurring pattern: pre-M39 implicit-set-aside-without-row methodology has left rows missing for non-inner-being uses (physical, cultic, etymological). Under v3_5 §3.2b skeleton-free model, these rows are now meaningful as pending and require explicit set-aside rows.

**Implication for the broader programme:** Other large-corpus Hebrew terms (especially those in registries with strong physical/cultic vocabulary — temple, sacrifice, purity, body, place names) may have analogous gaps. Consider a programme-wide audit of Hebrew terms with mismatched verse_context row-count vs. active-verse-count.

**Action:** Captured here for researcher awareness. Not a VCB-013 blocker.

---

## Summary table

| Flag | Term | Class | Resolution | Patch effect |
|---|---|---|---|---|
| DF-001 | G5544 | Description-class | Option C lean | VCREVISE OP-003 (verse_context update notes) |
| DF-002 | H2896A | Halt | Excluded | none (term not in any patch) |
| DF-003 | G2168 | Description-class | Option B lean | VCREVISE OP-001 (group_update) |
| DF-004 | H8549G | Halt | Excluded | none |
| DF-005 | G1258 | Halt (small) | Option B (resolve) | VERSECONTEXT OP-001 (verse_context insert set-aside) |
| DF-006 | H2181 | Halt | Excluded | none |
| DF-007 | H2183 | Description-class | Option B lean | VCREVISE OP-002 (group_update) |
| OBS-VC-001 | (instruction) | Soft | Note for future | none |
| OBS-VC-002 | G0861 | Soft | Note for future | none |
| OBS-VC-003 | G1261 | Soft | Note for future | none |
| SBF-VCB013-001 | G5544 | Session B flag | Carry to SB | VCSBFLAGS OP-001 |
| SBF-VCB013-002 | G2168 | Session B flag | Carry to SB | VCSBFLAGS OP-002 |
| PPO-VCB013-001 | (programme-wide) | Pattern observation | Researcher awareness | none |

---

*End of flags register. See `wa-vc-batch-13-obslog-v1_0-20260425.md` for full per-term reasoning.*
