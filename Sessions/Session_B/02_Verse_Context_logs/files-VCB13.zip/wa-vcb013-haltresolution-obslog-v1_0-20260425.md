# VCB-013 Halt Resolution — Observations Log

**Session:** VCB-013-HR (Halt Resolution sub-session of VCB-013)
**Date opened:** 2026-04-25
**Governing instruction:** wa-versecontext-instruction-v3_9-20260425.md
**Companion patch instruction:** wa-patch-instruction-v2_9-20260425.md
**Predecessor obslog:** wa-vc-batch-13-obslog-v1_0-20260425.md
**Predecessor patches (superseded by this session for the three halted terms):** none — terms 884, 934, 1221 were excluded from the original VCB-013 patches and will be added by this session.

---

## 1. Mandate

The original VCB-013 session halted three terms under VC §6.2 Step 2 partial-completion rule:

| Term | mti_id | Reg | Active verses | Existing rows | Pending |
|---|---|---|---|---|---|
| H2896A *tov* — pleasant | 884 | 067 | 306 | 165 | 141 |
| H8549G *ta.mim* — unblemished | 934 | 092 | 51 | 6 | 45 |
| H2181 *za.nah* — to fornicate | 1221 | 171 | 83 | 71 | 12 |

**Total pending verses across the three terms: 198.**

The researcher's instruction (2026-04-25):

> *"Were verses were actively grouped on context and found to be largely the same, I would agree with not evaluating those verses individually but as a homogenous group. I am not in agreement for the large number of verses that has not gone to any consideration. The halt condition is not 'ignore' it is 'investigate and find out why not previously done'. All these skipped verses must be considered."*

> *"create a new obslog to record the processes clean, and prepare new patches for the outcome. all verses need to be processed per the instruction, by term, given full attention, rather that a lighter touch, unless there is a clear reason why they must be skimped over."*

**Operative reading.** Halt under §6.2 Step 2 = stop and surface for researcher decision, not stop and discard. With researcher instruction now given, the work proceeds: investigate why the verses were skipped, then classify each on its own merits.

---

## 2. Working method

For each of the three terms:

1. **Read every active verse** — including those already with prior `verse_context` rows. The full corpus is the analytical unit.
2. **For unclassified verses:** apply the §3 relevance filter individually. Produce a verse-level outcome:
   - RELEVANT → assign to a group (existing or new)
   - SET-ASIDE → assign a controlled-vocabulary reason: `no_inner_being` / `physical_only` / `spatial_only` / `wrong_face` / `other`
3. **For already-classified verses:** review the existing classification under the current filter (§3) and group model (§6.2 Step 3). Note any verses where the prior classification is incorrect or where the existing groups may need re-thinking now that the full corpus is visible.
4. **Cluster-treat homogeneous blocks** — but only after reading each verse confirms homogeneity. Document the homogeneity finding before applying it. The cluster's filter outcome is one decision, but each verse is read, not skipped.
5. **Group description re-assessment** — the existing group descriptions were drawn from a partial corpus. Verify they still hold, or amend.

---

## 3. Sequence

Per researcher direction: **priority order — smallest first** (H8549G with 45 pending → H2181 with 12 pending → H2896A with 141 pending).

Rationale: each term is its own working session with its own pre-flight, full read, and final summary. Smallest first allows methodology to be visible on a tractable corpus before the largest commitment. **However**, H2181 has only 12 pending — even smaller. Adjusting:

- **First:** H2181 (12 pending) — smallest, lets the methodology be tested on a non-trivial but bounded set
- **Second:** H8549G (45 pending) — likely-homogeneous sacrificial-physical block; tests cluster-treatment discipline
- **Third:** H2896A (141 pending) — largest; will benefit from methodology refinement on the first two

---

## 4. Output plan

Following the original VCB-013 four-patch model. The three halted terms will be added back to:

- **VCREVISE v2** (`wa-vcb013-patch-vcrevise-v2-20260425.json`) — supersedes v1; adds 884, 934, 1221 to `terms_covered` + `input_versions`; adds any group_update / verse_context_update operations on the existing rows for these terms (where re-evaluation finds revisions are warranted)
- **VCNEW** (`wa-vcb013-patch-vcnew-v1-20260425.json`) — NEW patch class for this session; covers the first-time classification of the 198 pending verses (insert operations on `verse_context_group` for any new groups + `verse_context` for each newly-classified verse — relevant or set-aside)
- **VCSBFLAGS v2** (`wa-vcb013-patch-vcsbflags-v2-20260425.json`) — supersedes v1 if any new SB observations are raised
- **Flags register v2** (`wa-vcb013-flags-register-v2-20260425.md`) — supersedes v1
- **Session log v1 for halt-resolution** (`wa-vcb013-haltresolution-session-log-final-v1-20260425.md`)

The legacy VERSECONTEXT patch on G1258 (DF-005 Option B) is unchanged and stands.

**MIXED-pattern terms.** A halted term that yields both first-time inserts (for the previously-pending verses) AND updates to existing rows (where re-evaluation revises a prior classification) is a MIXED-pattern term per VC §6.3 Step 3 — preferred packaging is a single legacy VERSECONTEXT patch covering that term, not split across VCNEW + VCREVISE. I'll determine the routing per term as the work proceeds and adjust the file-output plan accordingly.

---

EOF
cp /home/claude/work/wa-vcb013-haltresolution-obslog-v1_0-20260425.md /mnt/user-data/outputs/wa-vcb013-haltresolution-obslog-v1_0-20260425.md 2>/dev/null || cp /home/claude/work/wa-vcb013-haltresolution-obslog-v1_0-20260425.md /mnt/user-data/outputs/
ls -la /home/claude/work/wa-vcb013-haltresolution-obslog-v1_0-20260425.md
# 5. TERM 1 of 3 (halt resolution) — H2181 *za.nah* — to fornicate

**Registry:** 171 whoredom
**mti_term_id:** 1221
**md_version:** v1
**Active verses:** 83
**Existing verse_context rows:** 71
**Pending verses:** 12
**Existing groups:** 5 active (1221-001 through 1221-005)
**Source file:** `wa-171-whoredom-H2181-session_a-20260425.md`

## §6.1 Step 4 — Version acknowledgement (A-03 gate)

> *"Term H2181 mti_id=1221 loaded at md_version=v1. This is the version that will be declared in the patch's `_patch_meta.input_versions[1221]`. If the DB's md_version for this term has changed by the time the patch is submitted, the patch will be rejected as stale."*

## §6.1 Step 5 — Prior-state posture

> *"Prior-state posture for H2181 (za.nah) mti_id=1221: HALT-RESOLUTION RE-EVALUATION. 5 active groups, 0 dissolved. 71 of 83 active verses have prior verse_context rows; 12 are pending and require first-time classification. Every prior classification will be reviewed against the current filter and grouping model in light of the now-visible full corpus; every pending verse will receive individual filter assessment and group decision. No silent pass-through; no skipping."*

## §6.2 Step 1 — Read all verses (full corpus, lexical context first)

**Lexical range (STEP):** *za.nah* — to commit fornication, be a harlot. Hebrew verb (qal) and participle. Used:
- Verbally — "to whore after" foreign gods (figurative-spiritual covenant unfaithfulness; majority of OT use)
- Verbally — to commit physical fornication
- As participle / nominal — "a prostitute" (a person who is/practises prostitution)

83 active OT occurrences. Distributed across Pentateuch (legal + narrative), Joshua (Rahab), Judges, Kings (narrative), and Prophets (figurative-spiritual + literal).

**Existing groups (drawn from the 71 prior-classified verses):**

| group_code | description |
|---|---|
| 1221-001 | Spiritual whoredom — Israel/Judah "whoring after" foreign gods, forsaking the Lord; covenantal heart-departure |
| 1221-002 | "A spirit of whoredom" — whoredom as a driving inner disposition and inner-being faculty |
| 1221-003 | "Your heart and your own eyes, which you are inclined to whore after" — the inner mechanism of desire as the root of whoredom |
| 1221-004 | Literal fornication as inner-being act — the will and desire engaged in sexual unfaithfulness |
| 1221-005 | Ezekiel's "whoring heart" allegory — inner-being characterisation of Jerusalem/Israel's spiritual condition |

**The 12 pending verses (read individually):**

| vid | ref | target word | full verse text |
|---|---|---|---|
| 46308 | Gen 38:15 | "prostitute" | "When Judah saw her, he thought she was a prostitute, for she had covered her face." |
| 46343 | Lev 21:7 | "prostitute" | "They shall not marry a prostitute or a woman who has been defiled..." |
| 46342 | Lev 21:14 | "prostitute" | "A widow, or a divorced woman, or a woman who has been defiled, or a prostitute, these he shall not marry..." |
| 207123 | Jos 2:1 | "prostitute" | "...And they went and came into the house of a prostitute whose name was Rahab and lodged there." |
| 207124 | Jos 6:17 | "prostitute" | "Only Rahab the prostitute and all who are with her in her house shall live, because she hid the messengers..." |
| 207125 | Jos 6:22 | "prostitute's" | "Go into the prostitute's house and bring out from there the woman and all who belong to her..." |
| 207126 | Jos 6:25 | "prostitute" | "But Rahab the prostitute and her father's household and all who belonged to her, Joshua saved alive..." |
| 46332 | Judg 11:1 | "prostitute" | "Now Jephthah the Gileadite was a mighty warrior, but he was the son of a prostitute..." |
| 207094 | 1Ki 3:16 | "prostitutes" | "Then two prostitutes came to the king and stood before him." |
| 207093 | 1Ki 22:38 | "prostitutes" | "...the prostitutes washed themselves in it, according to the word of the LORD that he had spoken." |
| 207122 | Joe 3:3 | "prostitute" | "...have traded a boy for a prostitute, and have sold a girl for wine..." |
| 207097 | Amo 7:17 | "prostitute" | "Your wife shall be a prostitute in the city, and your sons and your daughters shall fall by the sword..." |

## Reading observation — syntactic-semantic pattern

**All 12 pending verses use *za.nah* in participle / nominal form translated "prostitute"** (Hebrew זוֹנָה / זוֹנוֹת — qal active participle, used substantivally). This is morphologically distinct from the verbal uses (qal perfect / imperfect / infinitive) that dominate the 71 already-classified verses.

This is not coincidence. A prior session most likely recognised this morphological-semantic distinction and treated the participle-nominal uses as a separate analytical class — perhaps with the working assumption "the noun-form names a person, not an inner-being orientation, therefore filter as `no_inner_being`". That is an arguable analytical position. But it was not written into the database, leaving the 12 verses in pending limbo (which under v3_5 §3.2b is now a real analytical gap). My job is to confirm or revise that working assumption verse-by-verse.

## §6.2 Step 2 — Apply the relevance filter, verse by verse

The governing filter (§3): *Does this verse, through the use of this term, say something about the inner being — the non-physical, internal states, capacities, and expressions that constitute a person's invisible life?*

**Critical distinction (§3.5):** *"Relevance filter operates at the term level, not the verse level — inner-being content must be carried by the **target term itself**, not merely present in surrounding context."*

This is the key. Rahab is a paradigmatic inner-being figure — but her inner-being content (faith, fear, courage) is carried by other vocabulary (e.g. *yare* "fear", her confession in Jos 2:9-11). The word *za.nah* in the four Joshua verses names her *occupation*, not her inner being. Same logic for the legal categorical uses, the biographical references, and the narrative details.

I will work through each verse with this filter discipline.

### Verse-by-verse analysis

**vid=46308 — Gen 38:15** "When Judah saw her, he thought she was a prostitute, for she had covered her face."

The term identifies what *Judah inwardly thought* — his mistaken perception of Tamar's identity. The cognitive verb "thought" (חָשַׁב) carries the inner-being content; *za.nah* names the content of the thought. This is closer to inner-being engagement than the legal-categorical uses, but the inner-being content is carried by "thought", not by *za.nah* itself. The term is the *object* of Judah's perception; it names a category.

**Filter outcome:** SET-ASIDE — `no_inner_being`. *Reason: term names a categorical identity (prostitute) which Judah perceived; the inner-being engagement (Judah's mistaken perception) is carried by the cognitive verb, not by za.nah.*

**However**, this is a borderline case. An alternative reading would say the verse engages the inner-being theme of Tamar's circumstance and Judah's moral failure (which the Gen 38 narrative develops at length). I'll log this as a borderline retained for the flag list — researcher may prefer to retain in 1221-004 (literal fornication as inner-being act) on the grounds that the perceived category is morally laden.

**Working: SET-ASIDE no_inner_being. Borderline flagged.**

---

**vid=46343 — Lev 21:7** "They [the priests] shall not marry a prostitute or a woman who has been defiled, neither shall they marry a woman divorced from her husband, for the priest is holy to his God."

The term names a legal-categorical class of person whom priests are forbidden to marry. The verse engages the priestly holiness theme but the inner-being content (the priest's holiness, his ritual purity, his faithful service) is carried by "holy to his God" and the broader priestly-purity vocabulary, not by *za.nah*. *Za.nah* here names a forbidden-marriage category — like "widow" and "divorced woman" alongside it, all categorical legal terms.

**Filter outcome:** SET-ASIDE — `no_inner_being`. *Reason: term names a legal-categorical class of person; inner-being content of the verse (priestly holiness) is carried by other vocabulary.*

---

**vid=46342 — Lev 21:14** "A widow, or a divorced woman, or a woman who has been defiled, or a prostitute, these he shall not marry. But he shall take as his wife a virgin of his own people..."

Parallel construction to Lev 21:7 — the high priest's marriage restrictions. *Za.nah* in the same legal-categorical use.

**Filter outcome:** SET-ASIDE — `no_inner_being`. *Reason: same as Lev 21:7 — legal-categorical use of the term.*

---

**vid=207123 — Jos 2:1** "And they went and came into the house of a prostitute whose name was Rahab and lodged there."

The term names Rahab's social-occupational identity. Rahab herself is profoundly inner-being engaged in the narrative — Heb 11:31 calls her "by faith" — but her faith, fear of YHWH, and discernment are carried by other vocabulary in Jos 2:9-11. *Za.nah* here is a biographical descriptor.

**Filter outcome:** SET-ASIDE — `no_inner_being`. *Reason: term names Rahab's social-occupational identity; inner-being content of her narrative is carried by other vocabulary.*

---

**vid=207124 — Jos 6:17** "Only Rahab the prostitute and all who are with her in her house shall live, because she hid the messengers whom we sent."

Same logic — *za.nah* names Rahab's identity-descriptor. The inner-being content (Rahab's faithful action of hiding the messengers) is carried by "hid" and the connective "because".

**Filter outcome:** SET-ASIDE — `no_inner_being`.

---

**vid=207125 — Jos 6:22** "Go into the prostitute's house and bring out from there the woman and all who belong to her, as you swore to her."

Locational reference — "the prostitute's house". *Za.nah* in genitive construction identifies the house by its owner's occupation.

**Filter outcome:** SET-ASIDE — `no_inner_being` (alternative: `spatial_only`, but `no_inner_being` is the primary fit — the term identifies a person; "house" is the location). *Reason: term names a person whose house is identified; no inner-being engagement carried by the term.*

---

**vid=207126 — Jos 6:25** "But Rahab the prostitute and her father's household and all who belonged to her, Joshua saved alive..."

Identity-descriptor for Rahab.

**Filter outcome:** SET-ASIDE — `no_inner_being`.

---

**vid=46332 — Judg 11:1** "Now Jephthah the Gileadite was a mighty warrior, but he was the son of a prostitute. Gilead was the father of Jephthah."

Biographical-categorical use. The term names Jephthah's mother's social status — establishes the social-marginal context for Jephthah's life. The inner-being content of the broader Jephthah narrative (his vow, his daughter, his anguish) is not carried by *za.nah* in this verse.

**Filter outcome:** SET-ASIDE — `no_inner_being`. *Reason: biographical-categorical reference identifying Jephthah's parentage.*

---

**vid=207094 — 1Ki 3:16** "Then two prostitutes came to the king and stood before him."

Solomon's wisdom-judgement narrative. The term identifies the two women's social-occupational status — establishing why they have no other recourse (no husband, no family) and must come to the king. The inner-being content of the narrative (Solomon's wisdom; the true mother's compassion in v.26) is in other vocabulary.

**Filter outcome:** SET-ASIDE — `no_inner_being`.

---

**vid=207093 — 1Ki 22:38** "And they washed the chariot by the pool of Samaria, and the dogs licked up his blood, and the prostitutes washed themselves in it, according to the word of the LORD that he had spoken."

Narrative detail of Ahab's death — the prostitutes are incidental to the scene; the term identifies who happened to be at the pool. No inner-being engagement carried by *za.nah*. The verse's covenantal weight ("the word of the LORD") is in the prophetic-fulfilment frame, not in this term.

**Filter outcome:** SET-ASIDE — `no_inner_being`.

---

**vid=207122 — Joel 3:3** "...and have cast lots for my people, and have traded a boy for a prostitute, and have sold a girl for wine and have drunk it."

Prophetic indictment of human trafficking — the term identifies the commodity for which a boy was traded. The verse is morally weighty (judgement on the nations) but the inner-being content is carried by the indictment itself ("have cast lots... have traded... have sold... have drunk"); *za.nah* names what was given in trade — categorical.

**Filter outcome:** SET-ASIDE — `no_inner_being`. *Reason: term names a commodity in a transaction; the inner-being content of the indictment is carried by the verbs of action.*

**Borderline note:** the verse has strong inner-being weight (judgement of evil), but the term itself does not carry it.

---

**vid=207097 — Amos 7:17** "Therefore thus says the LORD: 'Your wife shall be a prostitute in the city, and your sons and your daughters shall fall by the sword, and your land shall be divided up with a measuring line; you yourself shall die in an unclean land, and Israel shall surely go into exile away from its land.'"

Prophetic curse on Amaziah the priest of Bethel. **This verse is materially different from the others in the unclassified set.** "Your wife shall be a prostitute" names a forced state of degradation as covenantal-judicial sentence. *Za.nah* here engages:

- The covenantal-relational disruption (Amaziah's family is sentenced because of his opposition to YHWH's prophet)
- The state of forced unfaithfulness as judgement (the wife is forced into the role)
- The honour-shame inner-being mechanics of the priestly household being publicly degraded

This is closer to **figurative-judicial use** of the term — the prostitute-state is the medium of YHWH's judgement on the inner-being-faithless priest. It engages the inner being through the term itself: the verse is naming what the term *will become true of* the priest's family as the inner-being-judicial response to the priest's covenant unfaithfulness.

**Filter outcome:** RELEVANT. *Reasoning: the term names the covenantal-judicial degraded state of Amaziah's wife as the inner-being judgement on the priest's faithlessness. Direct engagement (3.1: relational-covenantal disruption of inner-being orientation; the term itself carries the judicial-inner-being weight).*

**Group assignment:** review existing groups against this verse:
- 1221-001 (spiritual whoredom — Israel/Judah whoring after gods): does not fit — Amaziah's wife is not the subject of voluntary spiritual whoredom; she is the *passive recipient* of judgement.
- 1221-002 (spirit of whoredom — driving inner disposition): does not fit.
- 1221-003 (heart and eyes inclined to whore): does not fit.
- 1221-004 (literal fornication as inner-being act): partial fit — *literal* yes (becoming a prostitute is literal), but "inner-being act" is the wrong characterisation (the wife is not acting; she is being made-to-become).
- 1221-005 (Ezekiel's whoring heart allegory): does not fit.

**None of the existing 5 groups quite captures this verse.** The characteristic engaged is *judicial-degradation as covenantal consequence* — the inner-being effect of YHWH's judgement on the priestly household via the wife's forced degradation.

**This is a new-group candidate.** Provisional description: *"Whoredom as judicial degradation — the inner-being-disrupting covenant-judgement state where the term names a forced state of unfaithfulness imposed as YHWH's judicial sentence on the household of the inner-being-faithless"*. Anchor: Amos 7:17.

**However**, a single-verse new group is fragmentation against §6.2 grouping criterion. Three options:

- **Option A**: SET-ASIDE Amos 7:17 (treat similarly to the others) — under-classifies. The inner-being engagement is real.
- **Option B**: assign to 1221-004 with a notes annotation — the existing group's description "literal fornication as inner-being act — the will and desire engaged" doesn't fit the passive-recipient nature of Amos 7:17, but stretching it (or amending the description) could absorb the verse.
- **Option C**: create new group 1221-006 "Whoredom as judicial-degradation state imposed as covenant judgement" — single-verse group; clean but fragmenting.

I'll log this as **DF-HR-001** and lean toward **Option B with description amendment** for 1221-004 as the analytical choice — making the description cover both active-will and passive-judicial-imposition aspects.

**Working: RELEVANT, assigned to 1221-004 (provisional, pending DF-HR-001 resolution).**

## §6.2 Step 2 summary — verse-by-verse outcomes

| vid | ref | outcome | reasoning class |
|---|---|---|---|
| 46308 | Gen 38:15 | SET-ASIDE no_inner_being | Categorical (Judah's perception); borderline |
| 46343 | Lev 21:7 | SET-ASIDE no_inner_being | Legal-categorical |
| 46342 | Lev 21:14 | SET-ASIDE no_inner_being | Legal-categorical |
| 207123 | Jos 2:1 | SET-ASIDE no_inner_being | Identity-descriptor (Rahab) |
| 207124 | Jos 6:17 | SET-ASIDE no_inner_being | Identity-descriptor (Rahab) |
| 207125 | Jos 6:22 | SET-ASIDE no_inner_being | Identity-descriptor (Rahab) |
| 207126 | Jos 6:25 | SET-ASIDE no_inner_being | Identity-descriptor (Rahab) |
| 46332 | Judg 11:1 | SET-ASIDE no_inner_being | Biographical-categorical |
| 207094 | 1 Ki 3:16 | SET-ASIDE no_inner_being | Narrative identification |
| 207093 | 1 Ki 22:38 | SET-ASIDE no_inner_being | Narrative detail |
| 207122 | Joel 3:3 | SET-ASIDE no_inner_being | Categorical commodity |
| 207097 | Amos 7:17 | RELEVANT → 1221-004 (Option B) | Judicial-degradation; new facet |

11 set-asides + 1 relevant. The set-asides cohere as a single methodologically-uniform block (term names a person/category by occupation; inner-being engagement of the verse, where present, is carried by other vocabulary). The set-aside reasoning was applied per-verse; the homogeneity is established by reading each one. Where a verse came close to relevance (Gen 38:15, Joel 3:3) it was noted as borderline.

## §6.2 Step 2 — Re-examination of the 71 prior-classified verses

The full corpus is now visible. Two checks against the existing classification:

**Check 1: Is the participle-nominal vs. verbal split properly accounted for in the existing groups?**

The 71 already-classified verses are predominantly verbal forms ("Israel whored after"; "you shall not whore after"; etc.) and they are placed across groups 1221-001 (spiritual whoredom of Israel — the dominant group), 1221-002 (spirit of whoredom), 1221-003 (heart-and-eyes), 1221-004 (literal fornication as inner-being act), 1221-005 (Ezekiel allegory).

I've not done a verse-by-verse re-evaluation of the 71 prior rows in this session — the researcher's directive was on the unclassified verses. **However**, the new finding (12 of 12 pending verses are participle-nominal "prostitute" uses) raises a question: are there *also* participle-nominal uses among the 71 already-classified verses that may have been inappropriately placed in groups designed for verbal-spiritual-whoredom uses? This would require a re-read of the 71 — a substantial extra exercise.

**For this halt-resolution session, I do not undertake the 71-verse re-read.** I am working only on the unclassified gap as instructed. I log the question as **OBS-HR-001** for future consideration: *"Are there any participle-nominal uses among the 71 already-classified H2181 verses that should be reviewed for placement under the same set-aside-or-new-group logic now applied to the 12 pending verses?"*

**Check 2: Do any of the existing 5 group descriptions need amendment given the full corpus?**

Existing groups appear well-formed for the 71 verbal uses they contain. The Amos 7:17 finding (judicial-degradation facet) suggests that 1221-004's description ("Literal fornication as inner-being act — the will and desire engaged in sexual unfaithfulness") may need amendment to also cover passive-imposed states (Amos 7:17 case). This is **DF-HR-001** above.

## §6.2 Step 3 — Group relevant verses

Only 1 new RELEVANT verse from this halt-resolution: vid=207097 Amos 7:17. Working assignment: 1221-004 (pending DF-HR-001 group description amendment).

## §6.2 Step 4 — Anchor designation

Existing anchors for 1221-001 through 1221-005 are unchanged by this work. Amos 7:17 is **not** proposed as an anchor — it is a single distinctive facet within 1221-004; the existing 1221-004 anchor (whichever it is in the prior corpus) remains the primary evidential standalone for the literal-fornication characteristic.

(Note: I did not extract the existing anchor for 1221-004 in this halt-resolution work — the patch will only update 1221-004's description, not its anchor.)

## §6.2 Step 5 — Dual-context check

None.

## §6.2 Step 6 — Re-evaluation self-check

> *"Halt-resolution self-check for H2181 (za.nah) mti_id=1221:*
> *— Active verses: 83*
> *— Verses re-evaluated this session: 12 (the previously-pending set)*
> *— Verses retained at prior classification (not re-read this session): 71*
> *— Of the 12 newly-evaluated verses:*
> *    — Set-aside no_inner_being: 11*
> *    — Relevant, assigned to existing group (with description amendment): 1*
> *    — New groups created: 0 (Option B for DF-HR-001)*
> *— Group description amendments proposed: 1 (1221-004, per DF-HR-001)*
> *— Check: 11 set-aside + 1 relevant = 12 newly-evaluated verses. Total active rows post-apply: 71 (existing) + 12 (new) = 83 = active verse count. Coverage now 100%."*

## §6.2 Step 6 — Orphan-group check

> *"Orphan-group check for H2181 mti_id=1221:*
> *— Pre-existing active groups: 5*
> *— Active verse counts per group after halt-resolution: {1221-001: existing N1; 1221-002: existing N2; 1221-003: existing N3; 1221-004: existing N4 + 1 (Amos 7:17); 1221-005: existing N5}*
> *— No groups dissolved; no new groups created.*
> *— Orphan groups: NONE"*

(Existing per-group verse counts not enumerated in this halt-resolution session — they are unchanged from prior state.)

## Per-term Annexure B summary

```
Term: H2181 (za.nah) — to fornicate
mti_term_id: 1221
OWNER for: whoredom (registry 171)
Total verses: 83 | Newly classified this session: 12 | Set aside: 11 | Relevant: 1

Halt resolution:
  - 11 verses set aside (no_inner_being) — participle-nominal "prostitute" uses naming a person by occupation
  - 1 verse relevant (Amos 7:17) — judicial-degradation facet; assigned to 1221-004 with description amendment proposed
  - Group description revision proposed for 1221-004 (DF-HR-001)
  - No new groups; no anchor changes

Patch-contribution class: MIXED
  - 12 verse_context inserts (11 set-aside + 1 relevant assignment)
  - 1 verse_context_group update (description on 1221-004)
  → Legacy VERSECONTEXT patch (per VC §6.3 Step 3 to avoid VCNEW + VCREVISE md_version churn)

Borderline retained: Gen 38:15 (Judah's perception); Joel 3:3 (inner-being-weighted indictment with categorical use of term)
```

## SB / SD observations

- **OBS-HR-001** — All 12 unclassified verses for H2181 used participle-nominal forms ("prostitute") naming persons by occupation. The 71 verbal forms were classified under groups designed for inner-being engagement (spiritual whoredom, spirit of whoredom, etc.). Recommend a future review of the 71 prior classifications to verify no participle-nominal uses were inappropriately placed in inner-being-engagement groups.
- **SBF-HR-VCB013-001 (Session B flag candidate)** — The H2181 corpus exhibits a clear morphological-semantic split: verbal forms (figurative-spiritual covenant unfaithfulness or literal fornication-as-act) carry inner-being weight directly through the term; participle-nominal forms ("prostitute") name social/legal categories without inner-being engagement carried by the term itself, with one notable exception (Amos 7:17, judicial-degradation). Session B may want to consider whether this morphological split is a structural feature of Hebrew inner-being / inner-being-related vocabulary more broadly.

## DF-HR-001 — H2181 group 1221-004 description amendment

**Issue:** Amos 7:17 ("your wife shall be a prostitute in the city") engages the term in a judicial-degradation facet — a passive-imposed state, not an active-will engagement. The existing 1221-004 description ("Literal fornication as inner-being act — the will and desire engaged in sexual unfaithfulness") is active-will-only and does not cover the Amos 7:17 case.

**Options:**

- **Option A** — set Amos 7:17 aside, accept that the term in this verse is borderline. Inadequate; the term carries judicial-inner-being weight here.
- **Option B (Claude AI lean)** — amend 1221-004 description to cover both facets. Proposed text: *"Term names whoredom or its state in inner-being-engaged ways — the active will and desire engaged in sexual unfaithfulness, and the passively-imposed state of degradation as covenantal-judicial consequence on the inner-being-faithless household"*.
- **Option C** — create new single-verse group 1221-006 for the judicial-degradation facet. Fragments the analysis.

**Working: Option B applied** (description amendment for 1221-004).

## Patch routing decision

**Term H2181 mti_id=1221: patch-contribution class = MIXED. Will be packaged in legacy VERSECONTEXT patch covering this term. Operations:**
- 11 × insert on `verse_context` (set-aside rows for the 11 no_inner_being verses)
- 1 × insert on `verse_context` (relevant row for Amos 7:17, assigned to 1221-004)
- 1 × update on `verse_context_group` (description amendment on 1221-004 per DF-HR-001 Option B)

**Total: 13 operations on this term in the legacy VERSECONTEXT patch.**


## §6.2 Step 2 — Revisit (resolution of OBS-HR-001 / Gen 38:15 reconsideration)

After completing the initial 12-verse pass, I tested the question OBS-HR-001 raised by reading the 18 prior-classified "prostitute" verses among the 71 already-classified set. **Finding: the prior classifications are mostly defensible.** The prior classifier distinguished verses on the basis of *whether the verse engages inner-being content through the prostitute figure*, not on morphological form. This is the correct analytical basis.

However, the comparison surfaces an inconsistency in **my own** initial filter outcome on **Gen 38:15** (one of the 12 unclassified verses).

**Gen 38:15 reconsidered.**

Comparison:
- **Gen 34:31** (already classified, 1221-004 related): *"Should he treat our sister like a prostitute?"* — rhetorical question carrying the brothers' inner-being moral outrage; term names the contrastive identity Dinah was treated as.
- **Gen 38:15** (unclassified): *"When Judah saw her, he thought she was a prostitute, for she had covered her face."* — cognitive verb "thought" carrying Judah's inner-being mistaken perception; term names the content of the thought.

Both verses use *za.nah* in the same syntactic role — as the predicative content of an inner-being-engaging structure (rhetorical question / cognitive verb). The inner-being content of each verse is engaged *through* the term: in Gen 34:31, the moral degradation the brothers reject is named by *za.nah*; in Gen 38:15, the categorical identity Judah inwardly assigns is named by *za.nah*. They are analytically parallel.

**Revised filter outcome for Gen 38:15: RELEVANT** (revising my earlier set-aside lean). Group assignment: 1221-004 (parallel to Gen 34:31).

This is a correction to the term's verse-by-verse table given earlier in this section. The corrected counts:

| vid | ref | revised outcome |
|---|---|---|
| 46308 | Gen 38:15 | **RELEVANT → 1221-004** (revised from set-aside) |
| 46343 | Lev 21:7 | SET-ASIDE no_inner_being |
| 46342 | Lev 21:14 | SET-ASIDE no_inner_being |
| 207123 | Jos 2:1 | SET-ASIDE no_inner_being |
| 207124 | Jos 6:17 | SET-ASIDE no_inner_being |
| 207125 | Jos 6:22 | SET-ASIDE no_inner_being |
| 207126 | Jos 6:25 | SET-ASIDE no_inner_being |
| 46332 | Judg 11:1 | SET-ASIDE no_inner_being |
| 207094 | 1 Ki 3:16 | SET-ASIDE no_inner_being |
| 207093 | 1 Ki 22:38 | SET-ASIDE no_inner_being |
| 207122 | Joel 3:3 | SET-ASIDE no_inner_being (borderline — see note below) |
| 207097 | Amos 7:17 | RELEVANT → 1221-004 (Option B description amendment per DF-HR-001) |

**Joel 3:3 borderline note.** Compared to Deu 23:18 (already classified to 1221-004), Joel 3:3 has weaker inner-being weight: Deu 23:18 names the prostitute's fee as "abomination to the LORD" — direct cultic-relational engagement with YHWH; Joel 3:3 lists the prostitute as a trade-commodity in a generalised indictment. The inner-being-weight in Joel 3:3 is carried by the trafficking verbs ("cast lots, traded, sold, drunk"), not by *za.nah*. **Set-aside retained.** The decision is documented; it is not "flagged for another day" — the analytical reasoning is recorded and the patch will carry the explicit set-aside.

**Resolution of OBS-HR-001.** Resolved within this session. Prior classifications of "prostitute"-target-word verses among the 71 are defensible — the prior classifier worked on the same inner-being-engagement principle I am applying. No changes proposed to the 71 prior rows. The exercise was worth doing because it revealed my own Gen 38:15 mis-decision and confirmed the prior work's soundness.

## §6.2 Step 2 summary — REVISED verse-by-verse outcomes (final)

**Final counts for the 12 previously-unclassified H2181 verses:**

- SET-ASIDE no_inner_being: **10** (Lev 21:7, 21:14; Jos 2:1, 6:17, 6:22, 6:25; Judg 11:1; 1 Ki 3:16, 22:38; Joel 3:3)
- RELEVANT to 1221-004: **2** (Gen 38:15; Amos 7:17)

## Patch routing — REVISED

**Term H2181 mti_id=1221: patch-contribution class = MIXED. Operations on this term in legacy VERSECONTEXT patch:**

- 10 × insert on `verse_context` (set-aside rows for the 10 no_inner_being verses)
- 2 × insert on `verse_context` (relevant rows for Gen 38:15 → 1221-004 and Amos 7:17 → 1221-004)
- 1 × update on `verse_context_group` (description amendment on 1221-004 per DF-HR-001 Option B)

**Total: 13 operations on this term.**

(Operation count is unchanged from my initial estimate; the breakdown shifts by 1 — one fewer set-aside, one more relevant insert.)

## Final term-1 close

H2181 halt-resolution complete. All 12 previously-unclassified verses now have explicit filter outcomes recorded with reasoning. Two findings (DF-HR-001 group description amendment for 1221-004; Gen 38:15 correction from initial lean) resolved within this session, not deferred.


---

# 6. TERM 2 of 3 (halt resolution) — H8549G *ta.mim* — unblemished

**Registry:** 092 integrity
**mti_term_id:** 934
**md_version:** v1
**Active verses:** 51
**Existing verse_context rows:** 6
**Pending verses:** 45
**Existing groups:** 2 active (934-001, 934-002)
**Source file:** `wa-092-integrity-H8549G-session_a-20260425.md`

## §6.1 Step 4 — Version acknowledgement

> *"Term H8549G mti_id=934 loaded at md_version=v1. Will be declared in `input_versions[934]`."*

## §6.1 Step 5 — Prior-state posture

> *"Prior-state posture for H8549G (ta.mim) mti_id=934: HALT-RESOLUTION RE-EVALUATION. 2 active groups, 0 dissolved. 6 of 51 active verses have prior verse_context rows; 45 are pending. Every pending verse will be read and given an explicit filter outcome with reasoning."*

## §6.2 Step 1 — Read all verses (full corpus, lexical context first)

**Lexical range (STEP):** *ta.mim* — complete, whole, entire, sound; unblemished, perfect; sound/wholesome/innocent; in accord with truth and fact. Used:
- Of sacrificial animals — "without blemish / defect" (physical-cultic — must be physically perfect to be acceptable)
- Of God — "his way is perfect"; "perfect in knowledge"; "the law of the LORD is perfect" (inner-being / divine-attribute facet)
- Of human moral character — "blameless / having integrity" (this facet attested elsewhere via H8549H *ta.mim* — blameless; not in this term's corpus per STEP gloss)

**The 6 prior-classified verses (read for context):**

| vid | ref | target | classification |
|---|---|---|---|
| 173836 | Deu 32:4 | "perfect" | 934-001 anchor — "his work is perfect" (God's way) |
| 173835 | 2 Sa 22:31 | "perfect" | 934-001 related — "his way is perfect" (God) |
| 27772 | Job 36:4 | "perfect" | 934-001 related — Elihu's claim about himself ("perfect in knowledge"); arguably borderline but classified |
| 27773 | Job 37:16 | "perfect" | 934-001 anchor — "perfect in knowledge" (God) |
| 173847 | Psa 18:30 | "perfect" | 934-001 related — "his way is perfect" (God) |
| 173848 | Psa 19:7 | "perfect" | 934-002 anchor — "the law of the LORD is perfect" (Torah) |

The 6 prior verses all use *ta.mim* in the divine-perfection / Torah-perfection facet — direct inner-being engagement with the divine attribute or its inscripturated expression.

**The 45 pending verses (all read in full):**

| vid | ref | target | sub-pattern |
|---|---|---|---|
| 173837 | Exo 12:5 | without blemish | Passover lamb — physical-cultic |
| 173838 | Exo 29:1 | without blemish | Priestly consecration bull/rams — physical-cultic |
| 27775 | Lev 1:3 | without blemish | Burnt offering male — physical-cultic |
| 27774 | Lev 1:10 | without blemish | Burnt offering flock — physical-cultic |
| 27781 | Lev 3:1 | without blemish | Peace offering herd — physical-cultic |
| 27782 | Lev 3:6 | without blemish | Peace offering flock — physical-cultic |
| 27785 | Lev 4:3 | without blemish | Sin offering, anointed priest — physical-cultic |
| 27783 | Lev 4:23 | without blemish | Sin offering, ruler — physical-cultic |
| 27784 | Lev 4:28 | without blemish | Sin offering, common person — physical-cultic |
| 27786 | Lev 4:32 | without blemish | Sin offering, lamb — physical-cultic |
| 27787 | Lev 5:15 | without blemish | Guilt offering, breach of faith — physical-cultic |
| 27788 | Lev 5:18 | without blemish | Guilt offering, unintentional sin — physical-cultic |
| 27789 | Lev 6:6 | without blemish | Guilt offering — physical-cultic |
| 27790 | Lev 9:2 | without blemish | Aaron's inaugural offerings — physical-cultic |
| 27791 | Lev 9:3 | without blemish | Israel's inaugural offerings — physical-cultic |
| 27776 | Lev 14:10 | without blemish | Cleansed leper's offering — physical-cultic |
| 27777 | Lev 22:19 | without blemish | Acceptable male — physical-cultic |
| 27778 | Lev 22:21 | perfect | Peace/freewill offering — physical-cultic |
| 27779 | Lev 23:12 | without blemish | Wave-sheaf burnt offering — physical-cultic |
| 27780 | Lev 23:18 | without blemish | Festival offerings — physical-cultic |
| 27808 | Num 6:14 | blemish | Nazirite's offerings — physical-cultic |
| 27792 | Num 19:2 | defect | Red heifer (purification ritual) — physical-cultic |
| 27795 | Num 28:3 | blemish | Daily regular offering — physical-cultic |
| 27797 | Num 28:9 | blemish | Sabbath offering — physical-cultic |
| 27793 | Num 28:11 | blemish | New-moon offering — physical-cultic |
| 27794 | Num 28:19 | blemish | Passover offering — physical-cultic |
| 27796 | Num 28:31 | blemish | Festival regulations — physical-cultic |
| 27800 | Num 29:2 | blemish | Feast of Trumpets — physical-cultic |
| 27807 | Num 29:8 | blemish | Day of Atonement — physical-cultic |
| 27798 | Num 29:13 | blemish | Tabernacles day 1 — physical-cultic |
| 27799 | Num 29:17 | blemish | Tabernacles day 2 — physical-cultic |
| 27801 | Num 29:20 | blemish | Tabernacles day 3 — physical-cultic |
| 27802 | Num 29:23 | blemish | Tabernacles day 4 — physical-cultic |
| 27803 | Num 29:26 | blemish | Tabernacles day 5 — physical-cultic |
| 27804 | Num 29:29 | blemish | Tabernacles day 6 — physical-cultic |
| 27805 | Num 29:32 | blemish | Tabernacles day 7 — physical-cultic |
| 27806 | Num 29:36 | blemish | Tabernacles day 8 — physical-cultic |
| 173839 | Eze 43:22 | without blemish | Restored-temple altar purification — physical-cultic |
| 173840 | Eze 43:23 | without blemish | Restored-temple altar — physical-cultic |
| 173841 | Eze 43:25 | without blemish | Restored-temple altar 7-day — physical-cultic |
| 173842 | Eze 45:18 | without blemish | Restored-temple new-year purification — physical-cultic |
| 173843 | Eze 45:23 | without blemish | Restored-temple festival — physical-cultic |
| 173845 | Eze 46:4 | without blemish | Prince's Sabbath offering — physical-cultic |
| 173846 | Eze 46:6 | without blemish | Prince's new-moon offering — physical-cultic |
| 173844 | Eze 46:13 | without blemish | Prince's daily lamb — physical-cultic |

**Homogeneity finding (established by reading every verse):** all 45 pending verses use *ta.mim* in the formulaic sacrificial sense — the term qualifies an animal (lamb, bull, ram, goat, ewe, heifer) as physically perfect / unblemished, required for acceptable offering to YHWH. There is no exception in the 45-verse set. The contexts are: Pentateuchal sacrificial law (Exo, Lev, Num — 37 verses) and Ezekiel's restored-temple sacrificial law (Eze 43-46 — 8 verses). The morphological-cultic pattern is uniform.

## §6.2 Step 2 — Apply relevance filter (cluster-treated, homogeneity-justified)

**Filter discipline.** §3.5: relevance must be carried by the **target term itself**. In all 45 verses, *ta.mim* names the **physical-bodily wholeness of the sacrificial animal** — a literal, unimpaired, defect-free state of the offering. The verses are inner-being-weighted overall — sacrifice in Israel's worship is inner-being-laden in covenantal-relational terms (acceptance before YHWH, atonement, propitiation, fellowship); the *symbolic* pointer of the unblemished animal toward the perfect Christ is a Christological-typological reading the New Testament makes (1 Peter 1:19 *amōmos* = ta.mim) — but in the OT verse itself, *ta.mim* names a physical state of the animal, not an inner-being state of the worshipper or of God.

The filter outcome for the cluster is **SET-ASIDE — `physical_only`**. Reasoning:

- The term names a literal, physical, bodily state — defect-free, unblemished — required of an animal as a precondition for cultic acceptability.
- The inner-being content of these verses (acceptance before the LORD, atonement, fellowship, covenantal-relational standing) is carried by other vocabulary (*qarav* "to bring near"; *kafar* "to atone"; *ratzah* "be acceptable"; *qadosh* "holy"; the priestly-mediation framework), not by *ta.mim*.
- The term *ta.mim* in this physical-cultic facet is not metaphorically applied to a person's inner state in any of the 45 verses — it stays at the animal-physical level.
- This is a textbook `physical_only` set-aside: the term carries direct physical reference and the inner-being content of the verse is not borne by the term itself.

**Per-verse filter outcome:** SET-ASIDE `physical_only` for all 45 verses.

**Justification for cluster-treatment.** Every verse was read individually (table above lists each with its sub-pattern). The reading confirmed that all 45 verses share the same syntactic role for *ta.mim* (predicative qualifier of a sacrificial animal), the same semantic content (physical-bodily perfection of the offering), and the same filter outcome (physical-only with no inner-being weight carried by the term). The shared reasoning above is one reasoning, applied to one homogeneous block, after individual reading of each verse.

**No verses depart from the pattern.** I considered each Ezekiel verse individually because the restored-temple context is sometimes read as engaging eschatological / inner-being themes more directly than the Pentateuchal sacrificial code. But Ezekiel's restored-temple sacrifices (43:22-46:13) are described in straightforward sacrificial-cultic language with *ta.mim* applying to physical animals just as in Leviticus and Numbers. The eschatological-inner-being weight of the restored-temple vision is in the larger frame, not in this term in these verses.

## §6.2 Step 2 — Re-examination of the 6 prior-classified verses

Reading the 6 prior verses against the now-visible full corpus:

- **Deu 32:4, 2 Sa 22:31, Psa 18:30** — "his way is perfect" (God's way / God's character) — sound classification under 934-001.
- **Job 36:4, Job 37:16** — "perfect in knowledge" — 36:4 is Elihu speaking of himself (or claiming so on God's behalf); 37:16 is unambiguously about God. Both classified to 934-001. Job 36:4 is borderline (Elihu's self-description) but the prior classifier accepted it; I do not propose change.
- **Psa 19:7** — "the law of the LORD is perfect" — Torah, classified to 934-002. Sound.

**Group descriptions check:**
- 934-001 — *"Term characterises God's way, works, and knowledge as perfect — the inner perfection of divine character and action as the ground of trust"* — fits the 5 verses placed in it. Does NOT cover the 45 newly-set-aside verses (they are physical-cultic, not divine-attribute). Description sound; no amendment proposed.
- 934-002 — *"Term characterises the Torah as perfect — its completeness as the source of inner renewal of the soul"* — fits Psa 19:7 (the lone occupant). Description sound.

**No revisions to the 6 prior rows; no group-description amendments.** The set-aside of the 45 physical-cultic verses establishes them as a third sub-class of the term's corpus — not a group (set-asides do not have groups under R1) but a documented set-aside class with a single uniform reason.

## §6.2 Step 3 — Group relevant verses

No new RELEVANT verses from this halt-resolution. All 45 are SET-ASIDE.

## §6.2 Step 4 — Anchor designation

No anchor changes. Existing anchors (Deu 32:4, Job 37:16 for 934-001; Psa 19:7 for 934-002) retained.

## §6.2 Step 5 — Dual-context check

None.

## §6.2 Step 6 — Re-evaluation self-check

> *"Halt-resolution self-check for H8549G (ta.mim) mti_id=934:*
> *— Active verses: 51*
> *— Verses re-evaluated this session: 45 (the previously-pending set)*
> *— Verses retained at prior classification: 6*
> *— Of the 45 newly-evaluated verses:*
> *    — Set-aside physical_only: 45*
> *    — Relevant: 0*
> *— Group description amendments proposed: 0*
> *— Check: 45 set-aside + 0 relevant = 45 newly-evaluated. Total active rows post-apply: 6 (existing) + 45 (new) = 51 = active verse count. Coverage now 100%."*

## §6.2 Step 6 — Orphan-group check

> *"Orphan-group check for H8549G mti_id=934:*
> *— Pre-existing active groups: 2 (934-001, 934-002)*
> *— Active verse counts per group after halt-resolution: {934-001: 5 unchanged, 934-002: 1 unchanged}*
> *— Set-aside rows do not belong to any group (group_id NULL per R1).*
> *— Orphan groups: NONE"*

## Per-term Annexure B summary

```
Term: H8549G (ta.mim) — unblemished
mti_term_id: 934
OWNER for: integrity (registry 92)
Total verses: 51 | Newly classified this session: 45 | Set aside: 45 | Relevant: 0

Halt resolution:
  - 45 verses set aside (physical_only) — uniform sacrificial-physical use of the term naming the physical wholeness of an offered animal
  - Cluster homogeneity established by individual reading of every verse
  - No verses depart from the pattern; no exceptions
  - No relevant assignments; no new groups; no group description amendments; no anchor changes

Patch-contribution class: NEW-ONLY
  - 45 verse_context inserts (all set_aside_reason = 'physical_only')
  - 0 group operations
  → VCNEW patch (per VC §6.3 Step 3 — first-time inserts only, no updates)
```

## SB / SD observations

- **OBS-HR-002** — H8549G's corpus splits cleanly into two analytically distinct sub-classes: (a) divine/torah-perfection (the 6 prior-classified verses, in groups 934-001 and 934-002) — direct inner-being engagement with divine attribute; (b) sacrificial-physical (the 45 newly-set-aside verses) — physical_only set-aside, no inner-being engagement carried by the term itself in these verses. The Christological-typological reading (the unblemished animal as type of Christ in 1 Pet 1:19, etc.) is a New Testament inner-being engagement of the same concept via a different lemma (Greek *amōmos*). Session B may wish to track this OT physical → NT inner-being / Christological transposition pattern for the broader sacrifice / atonement vocabulary.

## Patch routing decision

**Term H8549G mti_id=934: patch-contribution class = NEW-ONLY. Will be packaged in VCNEW patch. Operations:**

- 45 × insert on `verse_context` (all `is_relevant=0`, `is_anchor=0`, `is_related=0`, `group_id=null`, `set_aside_reason='physical_only'`, descriptive `notes` per verse)
- 0 × group operations

**Total: 45 operations on this term in VCNEW.**


---

# 7. TERM 3 of 3 (halt resolution) — H2896A *tov* — pleasant

**Registry:** 067 goodness
**mti_term_id:** 884
**md_version:** v1
**Active verses:** 306
**Existing verse_context rows:** 165
**Pending verses:** 141
**Existing groups:** 6 active (884-001 through 884-006)
**Source file:** `wa-067-goodness-H2896A-session_a-20260425.md`

## §6.1 Step 4 — Version acknowledgement

> *"Term H2896A mti_id=884 loaded at md_version=v1. Will be declared in `input_versions[884]`."*

## §6.1 Step 5 — Prior-state posture

> *"Prior-state posture for H2896A (tov) mti_id=884: HALT-RESOLUTION RE-EVALUATION. 6 active groups, 0 dissolved. 165 of 306 active verses have prior verse_context rows; 141 pending — the largest pending set in this batch. Every pending verse will be read and given an explicit filter outcome with reasoning. Where homogeneous sub-classes emerge from the reading, cluster-treatment is applied with shared reasoning, but only after each verse is individually read and confirmed to fit the cluster pattern."*

## §6.2 Step 1 — Read all verses (full corpus, lexical context first)

**Lexical range (STEP):** *tov* — a Hebrew adjective with very wide range:
- Pleasant / agreeable to the senses
- Pleasant to the higher nature
- Good / excellent of its kind
- Good / valuable in estimation
- Appropriate / becoming
- Better (comparative)
- Glad / happy / prosperous (sensuous nature)
- Good understanding (intellectual nature)
- Kind / benign
- Right / ethical
- 409 OT occurrences total; 306 active in this corpus.

**Distribution observation.** The 165 prior-classified verses cluster heavily in wisdom / poetic literature (Pro 43, Psa 37, Ecc 13, Job 3 = 96 of 165 = 58%). The 141 pending verses cluster in narrative literature (Gen 31, Est 19, 1 Sa 15, Deu 14, 2 Sa 10, Judg 9 = 98 of 141 = 70%). This is consistent with a prior session that worked through wisdom/poetic uses (where *tov* is consistently inner-being-engaged: the upright, the wise, the good way) and stopped before the narrative corpus (where *tov* takes on many context-dependent meanings: physical descriptors, idioms, "as it pleases", etc.).

**Existing groups (drawn from the 165 prior-classified verses):**

| group_code | description |
|---|---|
| 884-001 | God's inner being as good — divine character, name, steadfast love, Spirit are good |
| 884-002 | Human moral character and conduct as good — inner quality of the upright person |
| 884-003 | Goodness as inner experiential good — what is genuinely good for the human person |
| 884-004 | Comparative wisdom good — "better-than" sayings of wisdom literature |
| 884-005 | God's good word and promise — covenantal faithfulness |
| 884-006 | The moral assessment of conduct/ways/deeds as not good — prophetic verdict |

These six groups cover the wisdom-literature and prophetic uses well. They do NOT obviously cover several patterns visible in the pending narrative corpus — see below.

## §6.2 Step 1 — Sub-pattern analysis from full reading

Before per-verse classification, I document the sub-patterns observable across the 141 pending verses (the patterns emerged from reading every verse). Each verse will then be classified individually but with reference to its sub-pattern.

| Sub-pattern | Verse count | Filter direction | Reasoning |
|---|---|---|---|
| **P1. Genesis 1 creation refrain "God saw that it was good"** | 7 | RELEVANT (potential new group) | Term names God's evaluative-relational pronouncement on creation; direct inner-being engagement of the Creator. |
| **P2. "Good old age"** | 3 | Borderline | Term names completed-life-quality at death. |
| **P3. "Good or bad / good or evil" merism** | 8 | SET-ASIDE no_inner_being | Idiomatic Hebrew construction meaning "anything at all"; term not engaging inner-being content. |
| **P4. Physical descriptor of objects/food/animals (non-land)** | ~25 | SET-ASIDE physical_only | Term names physical quality of items. |
| **P5. "Good land" (covenantal promise context)** | 11 | SET-ASIDE physical_only with note | Term names a physical territory; covenantal weight is in the surrounding promise vocabulary. |
| **P6. Aesthetic descriptor of persons ("attractive/beautiful/handsome")** | 13 | SET-ASIDE physical_only | Term names physical beauty; inner-being content of verse (e.g. Bathsheba) carried by other vocabulary. |
| **P7. "It pleases" / "seems good to" (volitional-preference idiom)** | ~30 | RELEVANT (likely new group) | Term names what is preferred/pleasing to the actor's will; inner-being engagement of volition. |
| **P8. Comparative "better than"** | ~12 | Mixed | Some inner-being-engaged (better counsel/path), some physical (better land/territory); per-verse assessment. |
| **P9. "Good counsel / good word / good speech"** | ~5 | RELEVANT | Term qualifies counsel/word/speech as inner-being-engaged judgement-evaluation. |
| **P10. Relational/emotional well-being states ("well disposed", "well", "joyful and glad")** | ~7 | RELEVANT | Term names inner-being state of well-being or relational disposition. |
| **P11. Misc. set-aside cases (figurative-physical, idiomatic feast-day, etc.)** | ~10 | SET-ASIDE per case | Heterogeneous tail; per-verse assessment. |

**Total: 141 verses across 11 sub-patterns. Estimates above are approximate; exact counts emerge from per-verse classification below.**


## §6.2 Step 2 — Per-verse classification (all 141 pending verses)

Each verse was read individually. Classifications below are by sub-pattern (P1–P11). Where verses cluster homogeneously within a sub-pattern, they share the same set-aside reason or group assignment, but each verse received individual reading and the reasoning column documents its specific case.


### Verse-by-verse decisions table

| vid | ref | sub-pattern | outcome | group / set-aside reason | reasoning |
|---|---|---|---|---|---|
| 24358 | Gen 1:4 | P1 | RELEVANT | 884-NEW-CR | Divine evaluative pronouncement on created light — God's inner-being action of judging-as-good |
| 24352 | Gen 1:10 | P1 | RELEVANT | 884-NEW-CR | Divine evaluative pronouncement on dry land/seas |
| 24353 | Gen 1:12 | P1 | RELEVANT | 884-NEW-CR | Divine evaluative pronouncement on vegetation |
| 24354 | Gen 1:18 | P1 | RELEVANT | 884-NEW-CR | Divine evaluative pronouncement on luminaries |
| 24355 | Gen 1:21 | P1 | RELEVANT | 884-NEW-CR | Divine evaluative pronouncement on sea creatures and birds |
| 24356 | Gen 1:25 | P1 | RELEVANT | 884-NEW-CR | Divine evaluative pronouncement on land animals |
| 24357 | Gen 1:31 | P1 | RELEVANT | 884-NEW-CR | Divine evaluative pronouncement on the whole creation — "very good" |
| 24365 | Gen 2:9 | P4 | SET-ASIDE | physical_only | "Good for food" — physical quality of trees in Eden |
| 24363 | Gen 2:12 | P4 | SET-ASIDE | physical_only | "Gold of that land is good" — physical-quality descriptor of gold |
| 24384 | Gen 6:2 | P6 | SET-ASIDE | physical_only | "Daughters of man were attractive" (tovat) — physical-aesthetic descriptor |
| 24359 | Gen 15:15 | P2 | SET-ASIDE (borderline) | no_inner_being | "Good old age" — names completed life-quality at death; tov modifies physical-temporal age |
| 24360 | Gen 16:6 | P7 | RELEVANT | 884-NEW-VP | "Do to her as you please" (good in your eyes) — names what is good/preferred to Abram's will; volitional engagement |
| 24361 | Gen 18:7 | P4 | SET-ASIDE | physical_only | "Calf, tender and good" — physical-quality of meat |
| 24362 | Gen 19:8 | P7 | RELEVANT | 884-NEW-VP | "Do to them as you please" — Lot offering daughters; tov as predicate of will |
| 24366 | Gen 20:15 | P7 | RELEVANT | 884-NEW-VP | "Where it pleases you" — Abimelech's permission; volitional preference |
| 24367 | Gen 24:16 | P6 | SET-ASIDE | physical_only | "Very attractive in appearance" (Rebekah) — physical beauty |
| 24368 | Gen 24:50 | P3 | SET-ASIDE | no_inner_being | "Cannot speak to you bad or good" — Hebrew merism for "anything at all" |
| 24369 | Gen 25:8 | P2 | SET-ASIDE (borderline) | no_inner_being | "Good old age" (Abraham's death) — names life-quality completion |
| 24370 | Gen 26:7 | P6 | SET-ASIDE | physical_only | "Attractive in appearance" (Rebekah) — physical beauty |
| 24371 | Gen 27:9 | P4 | SET-ASIDE | physical_only | "Good young goats" — physical-quality of animals for food |
| 24372 | Gen 29:19 | P8 | RELEVANT | 884-NEW-VP | "Better that I give her to you" — Laban's expressed preference/judgement; volitional-relational |
| 24374 | Gen 30:20 | P10 | SET-ASIDE | physical_only | "Good endowment" — names physical/material gift; Leah's claim about God's gift to her — borderline but tov here qualifies the physical endowment (sons/dowry) |
| 24375 | Gen 31:24 | P3 | SET-ASIDE | no_inner_being | "Either good or bad" — merism; God's warning to Laban |
| 24376 | Gen 31:29 | P3 | SET-ASIDE | no_inner_being | "Either good or bad" — merism; Laban citing God's warning |
| 24377 | Gen 40:16 | P9 | RELEVANT | 884-NEW-VP | "Interpretation was favorable (good)" — chief baker's evaluative judgement of Joseph's interpretation; inner-being assessment |
| 24382 | Gen 41:5 | P4 | SET-ASIDE | physical_only | "Plump and good ears of grain" — dream-content; physical quality of grain |
| 24378 | Gen 41:22 | P4 | SET-ASIDE | physical_only | Dream — physical quality of ears |
| 24379 | Gen 41:24 | P4 | SET-ASIDE | physical_only | Dream — physical quality of ears |
| 24380 | Gen 41:26 | P4 | SET-ASIDE | physical_only | Dream interpretation — physical quality of cows/ears |
| 24381 | Gen 41:35 | P4 | SET-ASIDE | physical_only | "Good years that are coming" — qualifies temporal/physical abundance years |
| 24383 | Gen 49:15 | P4 | SET-ASIDE | physical_only | "Resting place was good, land was pleasant" — Issachar oracle; tov names physical-quality of place |
| 164588 | Exo 2:2 | P6 | SET-ASIDE | physical_only | "He was a fine child" (Moses) — physical-aesthetic of infant |
| 164589 | Exo 3:8 | P5 | SET-ASIDE | physical_only | "Good and broad land" — covenantal-promise but tov names the physical territory |
| 24427 | Lev 27:10 | P3 | SET-ASIDE | no_inner_being | "Good for bad" merism; legal-substitution |
| 24428 | Lev 27:12 | P3 | SET-ASIDE | no_inner_being | "Either good or bad" — priestly valuation merism |
| 24429 | Lev 27:14 | P3 | SET-ASIDE | no_inner_being | "Either good or bad" — priestly valuation merism |
| 24430 | Lev 27:33 | P3 | SET-ASIDE | no_inner_being | "Between good or bad" — substitution merism |
| 24444 | Num 13:19 | P3 | SET-ASIDE | no_inner_being | "Land is good or bad" — spies' reconnaissance question (merism for evaluation framework) |
| 24446 | Num 14:7 | P5 | SET-ASIDE | physical_only | "Land is exceedingly good land" — Joshua/Caleb spy report; physical-territorial |
| 24447 | Num 36:6 | P7 | RELEVANT | 884-NEW-VP | "Marry whom they think best" — Zelophehad's daughters' preference; volitional |
| 164535 | Deu 1:14 | P7 | RELEVANT | 884-NEW-VP | "Thing you have spoken is good for us to do" — people's evaluative agreement |
| 164536 | Deu 1:25 | P5 | SET-ASIDE | physical_only | "Good land that the LORD our God is giving us" — covenantal promise; tov names land |
| 164537 | Deu 1:35 | P5 | SET-ASIDE | physical_only | "Good land swore to give to your fathers" — covenant; physical territory |
| 164543 | Deu 3:25 | P5 | SET-ASIDE | physical_only | "Good land beyond Jordan, good hill country" — physical territory |
| 164545 | Deu 4:21 | P5 | SET-ASIDE | physical_only | "Good land for inheritance" — covenant; physical |
| 164546 | Deu 4:22 | P5 | SET-ASIDE | physical_only | "Take possession of that good land" — physical territory |
| 164547 | Deu 6:10 | P5 | SET-ASIDE | physical_only | "Great and good cities" — physical-quality of cities |
| 164551 | Deu 8:7 | P5 | SET-ASIDE | physical_only | "Good land — brooks of water, fountains" — physical territory |
| 164550 | Deu 8:12 | P4 | SET-ASIDE | physical_only | "Good houses" — physical structures |
| 164538 | Deu 11:17 | P5 | SET-ASIDE | physical_only | "Good land that the LORD is giving" — physical territory |
| 164540 | Deu 19:13 | P10 | RELEVANT | 884-NEW-WB | "Well with you" — names the state of well-being / shalom resulting from purging guilt; relational-covenantal inner-being state |
| 164541 | Deu 23:16 | P7 | RELEVANT | 884-NEW-VP | "Wherever it suits him" (in good in his eyes) — runaway slave's preference; volitional |
| 164542 | Deu 28:12 | P4 | SET-ASIDE | physical_only | "His good treasury, the heavens" — figurative-physical (rain/blessing source) |
| 164544 | Deu 30:9 | P10 | RELEVANT | 884-NEW-WB | "Make you abundantly prosperous" — covenantal-relational well-being; tov names the state of being-prospered |
| 164610 | Jos 7:21 | P6 | SET-ASIDE | physical_only | "Beautiful cloak from Shinar" — Achan's coveted item; physical-aesthetic |
| 164611 | Jos 9:25 | P7 | RELEVANT | 884-NEW-VP | "Whatever seems good and right in your sight" — Gibeonites; volitional submission |
| 164606 | Jos 23:13 | P5 | SET-ASIDE | physical_only | "This good ground that the LORD has given" — covenantal land |
| 24417 | Judg 8:2 | P8 | RELEVANT | 884-004 | "Better the gleaning of Ephraim than the harvest of Abiezer" — Gideon's rhetorical comparative wisdom; fits 884-004 comparative-wisdom-good |
| 24418 | Judg 8:32 | P2 | SET-ASIDE (borderline) | no_inner_being | "Gideon died in good old age" — completed life |
| 24420 | Judg 9:2 | P8 | RELEVANT | 884-004 | "Better seventy or one rule" — Abimelech's rhetorical comparative for political choice; volitional-evaluative |
| 24419 | Judg 9:11 | P4 | SET-ASIDE | physical_only | "My sweetness and my good fruit" — fig tree parable; physical fruit-quality |
| 24412 | Judg 10:15 | P7 | RELEVANT | 884-NEW-VP | "Do to us whatever seems good to you" — Israel's repentant submission to God; volitional |
| 24413 | Judg 15:2 | P6 | SET-ASIDE | physical_only | "Younger sister more beautiful" — Samson's wife's sister; physical aesthetic |
| 24415 | Judg 18:9 | P5 | SET-ASIDE | physical_only | "We have seen the land, behold it is very good" — Dan's spies; physical territory |
| 24414 | Judg 18:19 | P8 | RELEVANT | 884-004 | "Better priest to one man or to a tribe" — Danites' rhetorical preference; comparative |
| 24416 | Judg 19:24 | P7 | RELEVANT | 884-NEW-VP | "Do with them what seems good to you" — Levite's host offering daughter/concubine; volitional (a deeply morally fraught instance, but tov's engagement is volitional-preference) |
| 164695 | Rut 2:22 | P7 | RELEVANT | 884-NEW-VP | "It is good, my daughter, that you go out" — Naomi's evaluative judgement/counsel |
| 164696 | Rut 3:13 | P9 | RELEVANT | 884-NEW-VP | "If he will redeem you, good" — Boaz's conditional agreement-judgement |
| 164493 | 1Sa 1:23 | P7 | RELEVANT | 884-NEW-VP | "Do what seems best to you" — Elkanah to Hannah; volitional submission |
| 164516 | 1Sa 3:18 | P7 | RELEVANT | 884-NEW-VP | "Let him do what seems good to him" — Eli's submission to God's judgement |
| 164517 | 1Sa 8:14 | P4 | SET-ASIDE | physical_only | "Best of fields/vineyards/olives" — Samuel's warning; physical-quality property |
| 164518 | 1Sa 8:16 | P4 | SET-ASIDE | physical_only | "Best of young men/donkeys" — physical-extraction warning |
| 164520 | 1Sa 9:2 | P6 | SET-ASIDE | physical_only | "Saul handsome young man, more handsome" — physical-aesthetic |
| 164519 | 1Sa 9:10 | P9 | RELEVANT | 884-NEW-VP | "Well said" — Saul's agreement to servant's suggestion |
| 164495 | 1Sa 11:10 | P7 | RELEVANT | 884-NEW-VP | "Do whatever seems good to you" — Jabesh-gilead's submission |
| 164497 | 1Sa 14:36 | P7 | RELEVANT | 884-NEW-VP | "Do whatever seems good to you" — people to Saul |
| 164498 | 1Sa 14:40 | P7 | RELEVANT | 884-NEW-VP | "Do what seems good to you" — people to Saul |
| 164501 | 1Sa 16:12 | P6 | SET-ASIDE | physical_only | "Ruddy, beautiful eyes, handsome" (David) — physical-aesthetic |
| 164502 | 1Sa 16:16 | P10 | RELEVANT | 884-NEW-WB | "You will be well" (relief from harmful spirit) — names inner-being state of relief/well-being |
| 164507 | 1Sa 20:7 | P9 | RELEVANT | 884-NEW-VP | "If he says 'Good!'" — Saul's inner approval/agreement (cf. inner-being engagement of agreement) |
| 164506 | 1Sa 20:12 | P10 | RELEVANT | 884-NEW-WB | "Well disposed toward David" — Saul's relational-emotional disposition; inner-being |
| 164511 | 1Sa 25:8 | P11 | SET-ASIDE | no_inner_being | "Feast day" (yom tov) — idiomatic noun-phrase for festival day |
| 164513 | 1Sa 27:1 | P8 | RELEVANT | 884-004 | "Nothing better than escape" — David's inward judgement spoken in his heart; comparative-wisdom |
| 164533 | 2Sa 3:13 | P9 | RELEVANT | 884-NEW-VP | "Good; I will make a covenant" — David's conditional agreement |
| 164522 | 2Sa 11:2 | P6 | SET-ASIDE | physical_only | "Bathsheba very beautiful" — physical-aesthetic |
| 164524 | 2Sa 14:32 | P8 | RELEVANT | 884-004 | "Better for me to be there still" — Absalom's preference; comparative |
| 164525 | 2Sa 15:3 | P9 | RELEVANT | 884-NEW-VP | "Your claims are good and right" — Absalom's flattering evaluation |
| 164527 | 2Sa 17:7 | P9 | RELEVANT | 884-004 | "Counsel of Ahithophel is not good" — Hushai's evaluative judgement on counsel |
| 164526 | 2Sa 17:14 | P9 | RELEVANT | 884-004 | "Good counsel of Ahithophel" — narrator's evaluation; same engagement |
| 164529 | 2Sa 18:3 | P8 | RELEVANT | 884-004 | "Better that you send help from city" — Joab's men advising; preferential |
| 164530 | 2Sa 19:18 | P7 | RELEVANT | 884-NEW-VP | "Do his pleasure" (good in his eyes) — servants of king's preference |
| 164531 | 2Sa 19:27 | P7 | RELEVANT | 884-NEW-VP | "Do what seems good to you" — Mephibosheth to David |
| 164532 | 2Sa 19:38 | P7 | RELEVANT | 884-NEW-VP | "Whatever seems good to you" — David to Barzillai |
| 164601 | Ezr 8:27 | P4 | SET-ASIDE | physical_only | "Two vessels of fine bright bronze" — physical-quality of metalwork |
| 24437 | Neh 2:5 | P7 | RELEVANT | 884-NEW-VP | "If it pleases the king" — Nehemiah; volitional-relational request |
| 24438 | Neh 2:7 | P7 | RELEVANT | 884-NEW-VP | "If it pleases the king" — Nehemiah; same |
| 24439 | Neh 2:8 | P11 | RELEVANT | 884-005 | "Good hand of my God was upon me" — Nehemiah's recognition of God's favorable providential action; covenantal-relational. Fits 884-005 (God's good word/promise/faithfulness) |
| 164567 | Est 1:11 | P6 | SET-ASIDE | physical_only | "Vashti lovely to look at" — physical-aesthetic |
| 164568 | Est 1:19 | P7 | RELEVANT | 884-NEW-VP | "If it please the king" — Memucan's counsel |
| 164569 | Est 2:2 | P6 | SET-ASIDE | physical_only | "Beautiful young virgins" — physical-aesthetic |
| 164570 | Est 2:3 | P6 | SET-ASIDE | physical_only | "Beautiful young virgins" — physical-aesthetic |
| 164571 | Est 2:7 | P6 | SET-ASIDE | physical_only | "Esther beautiful figure, lovely to look at" — physical-aesthetic |
| 164572 | Est 2:9 | P4 | SET-ASIDE | physical_only | "Best place in the harem" — physical-spatial advantage |
| 164574 | Est 3:9 | P7 | RELEVANT | 884-NEW-VP | "If it please the king" — Haman's decree request |
| 164573 | Est 3:11 | P7 | RELEVANT | 884-NEW-VP | "As it seems good to you" — king's permission to Haman |
| 164575 | Est 5:4 | P7 | RELEVANT | 884-NEW-VP | "If it please the king" — Esther |
| 164576 | Est 5:8 | P7 | RELEVANT | 884-NEW-VP | "If it please the king" — Esther |
| 164577 | Est 5:9 | P10 | RELEVANT | 884-NEW-WB | "Joyful and glad of heart" (tov-lev) — Haman's inner emotional state; explicit inner-being engagement |
| 164578 | Est 7:3 | P7 | RELEVANT | 884-NEW-VP | "If it please the king" — Esther |
| 164579 | Est 7:9 | P11 | SET-ASIDE | no_inner_being | "Whose word saved the king" (target rendered "word" — likely tov is part of phrase "good word" / spoke favorably about the king); narrative description of past action; the inner-being content of Mordecai's loyalty is in the underlying narrative, not in tov here. Borderline — flagging. |
| 164581 | Est 8:5 | P7 | RELEVANT | 884-NEW-VP | "If it please the king" — Esther |
| 164582 | Est 8:8 | P7 | RELEVANT | 884-NEW-VP | "Write as you please" — king to Esther/Mordecai |
| 164580 | Est 8:17 | P11 | SET-ASIDE | no_inner_being | "Holiday" (yom tov) — idiomatic festival-day |
| 164583 | Est 9:13 | P7 | RELEVANT | 884-NEW-VP | "If it please the king" — Esther |
| 164584 | Est 9:19 | P11 | SET-ASIDE | no_inner_being | "Holiday" (yom tov) — idiomatic festival-day |
| 164585 | Est 9:22 | P11 | SET-ASIDE | no_inner_being | "Holiday" — idiomatic festival-day |
| 164653 | Pro 3:4 | P10 | RELEVANT | 884-002 | "Good success in sight of God and man" — names the inner-being-relational state of the upright; fits 884-002 (human moral character). Wisdom literature. |
| 164642 | Pro 24:13 | P4 | SET-ASIDE | physical_only | "Honey is good" — physical-quality; introductory metaphor for wisdom in following verses, but tov here qualifies the physical honey |
| 164654 | Pro 31:18 | P11 | RELEVANT | 884-002 | "Her merchandise is profitable (good)" — Pro 31 woman's wisdom-in-action; inner-being-engaged through her industriousness |
| 164555 | Ecc 2:3 | P10 | RELEVANT | 884-003 | "What was good for the children of man to do" — Qoheleth's search; experiential-good for human persons; fits 884-003 |
| 24392 | Isa 5:9 | P4 | SET-ASIDE | physical_only | "Beautiful houses desolate" — physical-aesthetic of buildings |
| 24389 | Isa 39:2 | P4 | SET-ASIDE | physical_only | "Precious oil" (tov) — Hezekiah's treasure; physical-quality |
| 24391 | Isa 41:7 | P9 | RELEVANT | 884-NEW-VP | "Saying of the soldering, It is good" — craftsman's evaluative judgement on workmanship; inner-being assessment |
| 24408 | Jer 6:20 | P4 | SET-ASIDE | physical_only | "Sweet (good) cane from distant land" — physical-quality of incense/cane offering material |
| 24398 | Jer 24:2 | P4 | SET-ASIDE | physical_only | "Good figs" — physical-quality (vision content; symbolism is in the broader narrative) |
| 24399 | Jer 24:3 | P4 | SET-ASIDE | physical_only | "Good figs very good" — physical-quality in vision |
| 24400 | Jer 24:5 | P4 | SET-ASIDE | physical_only | "Like these good figs, so I will regard the exiles" — vehicle of metaphor; tov in vehicle qualifies physical figs (the tenor is the exiles' inner-being-relational status, but tov names the figs) |
| 24401 | Jer 26:14 | P7 | RELEVANT | 884-NEW-VP | "Do with me as seems good and right to you" — Jeremiah's submission |
| 24405 | Jer 40:4 | P7 | RELEVANT | 884-NEW-VP | "If it seems good to you to come" / "go wherever you think good and right" — Nebuzaradan to Jeremiah; volitional preference |
| 24406 | Jer 44:17 | P10 | RELEVANT | 884-006 | "We had plenty of food and prospered" — Jeremiah's opponents recalling their false prosperity in idolatry; fits 884-006 (prophetic verdict on conduct as not-good — here ironic, the people's self-justification is itself the prophetic indictment) — borderline; could also be 884-NEW-WB. Lean: 884-006 since this is reported speech in a prophetic indictment context. |
| 24425 | Lam 4:1 | P4 | SET-ASIDE | physical_only | "Pure gold (tov) is changed" — physical-quality of gold (figurative for Zion's former glory; tov names the physical metal in the vehicle) |
| 164590 | Eze 17:8 | P5 | SET-ASIDE | physical_only | "Good soil" — figurative-vine; tov names physical agricultural quality in the vehicle |
| 164593 | Eze 24:4 | P4 | SET-ASIDE | physical_only | "Good pieces of meat" — Ezekiel's pot allegory; tov names physical-quality of meat in vehicle |
| 164594 | Eze 31:16 | P4 | SET-ASIDE | physical_only | "Choice and best of Lebanon" (trees) — figurative; tov of physical trees |
| 164595 | Eze 34:14 | P5 | SET-ASIDE | physical_only | "Good pasture, good grazing land" — Ezekiel's shepherd allegory; the relational tenor (God shepherding faithfully) is in the broader allegory; tov here qualifies physical pasture in the vehicle |
| 24350 | Dan 1:15 | P6 | SET-ASIDE | physical_only | "Better in appearance, fatter in flesh" — physical-aesthetic comparison |
| 24386 | Hos 4:13 | P4 | SET-ASIDE | physical_only | "Their shade is good" (trees of high places used in idolatry) — physical-quality of shade; the verse's inner-being weight (idolatry indictment) is in the surrounding sacrificial-action verbs, not in tov |
| 164602 | Joe 3:5 | P4 | SET-ASIDE | physical_only | "Rich (good) treasures" — physical wealth taken into pagan temples |
| 164534 | Amo 6:2 | P8 | RELEVANT | 884-004 | "Are you better than these kingdoms?" — Amos' rhetorical comparative; warning to Israel; fits 884-004 (comparative wisdom good as judgement-frame) |
| 24435 | Nah 3:4 | P11 | SET-ASIDE | physical_only | "Graceful (tov) and of deadly charms" (prostitute Nineveh) — figurative-physical aesthetic of personification; the inner-being weight is in the figurative-political indictment, not in tov which qualifies the prostitute-figure's aesthetic |
| 164699 | Zec 11:12 | P7 | RELEVANT | 884-NEW-VP | "If it seems good to you, give me my wages" — symbolic shepherd to flock; volitional preference |
## §6.2 Step 3 — Group relevant verses (characteristic-perspective)

Three new groups are proposed for H2896A based on patterns the now-visible full corpus reveals:

### Proposed group 884-007 (provisionally 884-NEW-CR — Creation evaluative pronouncement)

**Description (proposed):** *"Term names God's evaluative pronouncement on his creation — the divine inner-being action of judging-and-declaring-good in Gen 1, where the Creator inspects what he has made and pronounces it good or very good"*

**Verses (7):** Gen 1:4, 1:10, 1:12, 1:18, 1:21, 1:25, 1:31.

**Anchor:** Gen 1:31 (vid=24357) — *"And God saw everything that he had made, and behold, it was very good"* — the climactic pronouncement after the whole work, evidentially standalone for the characteristic.

**Why a new group is warranted.** The existing groups all describe inner-being characteristics of humans, of God's word/promise, or of human conduct. None covers the unique inner-being action of God's evaluative pronouncement on his creation. The Gen 1 refrain is a 7-verse cluster speaking of God's inner-being-evaluation as creator — distinct from 884-001 (God's character as good — passive divine-attribute) and 884-005 (God's good word/promise — covenantal-promissory). The creation-evaluative facet is its own characteristic and deserves its own group.

### Proposed group 884-008 (provisionally 884-NEW-VP — Volitional preference / "as it pleases / seems good")

**Description (proposed):** *"Term names what is good-in-the-eyes-of / pleasing to / preferred-by an actor — the volitional-preference idiom in which the term is the predicate of someone's will or evaluative agreement, naming what they choose, prefer, agree to, or judge fitting"*

**Verses (40):** Gen 16:6, 19:8, 20:15, 29:19, 40:16; Num 36:6; Deu 1:14, 23:16; Jos 9:25; Judg 10:15, 19:24; Rut 2:22, 3:13; 1 Sa 1:23, 3:18, 9:10, 11:10, 14:36, 14:40, 20:7; 2 Sa 3:13, 15:3, 19:18, 19:27, 19:38; Neh 2:5, 2:7; Est 1:19, 3:9, 3:11, 5:4, 5:8, 7:3, 8:5, 8:8, 9:13; Isa 41:7; Jer 26:14, 40:4; Zec 11:12.

**Anchor candidate:** **Jer 26:14** (vid=24401) — *"As for me, behold, I am in your hands. Do with me as seems good and right to you"* — Jeremiah's submission; the term is precisely the predicate of what the actors should choose. Standalone and evidentially clean. Or alternatively **2 Sa 19:38** for the David-to-Barzillai instance. Jer 26:14 is stronger.

**Why a new group is warranted.** This is a 40-verse pattern in the H2896A corpus and not represented in the existing 6 groups. The volitional-preference idiom is a major use of *tov* — it names the predicate of an actor's evaluative-volitional act of preferring, agreeing, judging-fitting, or submitting to another's preference. It is unambiguously inner-being-engaged: the term is the exact content of the volitional faculty's choice or evaluation. Without this group, 40 verses would be either uncovered or forcibly placed in an ill-fitting group (e.g. 884-002 human moral character is about *whether someone is morally good*, not *what someone judges to be good for them to do*).

### Proposed group 884-009 (provisionally 884-NEW-WB — Inner well-being / relational-emotional state)

**Description (proposed):** *"Term names a state of inner well-being — the shalom-condition of being-well, prospering, glad-of-heart, or well-disposed — the inner-being state experienced or sought by the human person"*

**Verses (5):** Deu 19:13, 30:9; 1 Sa 16:16, 20:12; Est 5:9.

**Anchor candidate:** **Est 5:9** (vid=164577) — *"Haman went out that day joyful and glad of heart"* (literally *tov-lev* — "good of heart") — explicit inner-being-emotional state named by the term.

**Why a new group is warranted.** Five verses where *tov* names not the goodness-as-quality of the person or situation but the **inner-being state of being-well**. This is distinct from 884-002 (the person *as good*) and 884-003 (what is *experientially good for* the person — though 884-003 is the closest existing group). I considered placing these in 884-003. The distinction: 884-003 names *what is good for the person* (proximity to God, communal harmony, etc. — objects of the human's good); 884-NEW-WB names *the inner state of being-well* (the subjective state itself — gladness, prosperity, well-disposedness). Borderline against 884-003 — the alternative is to absorb these 5 verses into 884-003 with a description amendment broadening 884-003 to include the subjective-state facet. **Logged as DF-HR-002 — researcher decision.**

### Verses placed in existing groups

| Verse | Group | Reason |
|---|---|---|
| Pro 3:4 | 884-002 | "Good success in sight of God and man" — names inner state of the upright |
| Pro 31:18 | 884-002 | Pro 31 woman's profitable enterprise — wisdom-in-action, moral character |
| Ecc 2:3 | 884-003 | "What is good for the children of man to do" — Qoheleth's experiential search |
| Judg 8:2; 9:2; 18:19; 1 Sa 27:1; 2 Sa 14:32; 17:7; 17:14; 18:3; Amos 6:2 | 884-004 | Comparative "better-than" judgements; counsel evaluations |
| Neh 2:8 | 884-005 | "Good hand of God upon me" — covenantal-providential favour |
| Jer 44:17 | 884-006 | "We had plenty and prospered" — Jeremiah's opponents' false-prosperity speech, fits prophetic-verdict frame (the verse is in a passage where God indicts this very speech as evidence of inner-being-faithlessness) |

## DF-HR-002 — H2896A new groups (884-007, 884-008, 884-009)

**Issue:** Three new groups proposed for H2896A based on full-corpus reading of the 141 pending verses. Researcher decision required at apply-time on:
- 884-007 (creation evaluative pronouncement) — 7 verses, well-defined, clear gap in existing 6-group set
- 884-008 (volitional-preference idiom) — 40 verses, very strong corpus, clear gap
- 884-009 (inner well-being state) — 5 verses; alternative is to absorb into 884-003 with description amendment

**Claude AI lean:**
- 884-007 — **CREATE** (clear gap, 7-verse strong cluster)
- 884-008 — **CREATE** (clear gap, 40-verse cluster, central to narrative-corpus use of tov)
- 884-009 — **CREATE** as separate group, OR alternatively absorb into 884-003 with description amendment. Lean: **CREATE** as separate group — the subjective-inner-state facet is meaningfully distinct from the objects-of-experiential-good facet of 884-003.

## §6.2 Step 4 — Anchor designation

Existing anchors for the 6 prior groups are unchanged. Proposed anchors for the 3 new groups (above):
- 884-007 anchor: Gen 1:31 (vid=24357)
- 884-008 anchor: Jer 26:14 (vid=24401)
- 884-009 anchor: Est 5:9 (vid=164577)

## §6.2 Step 5 — Dual-context check

A few verses sit at sub-pattern boundaries (Pro 3:4 — wisdom-character + relational success; Jer 44:17 — well-being state framed in prophetic indictment). Each was assigned to a single group with reasoning given. No dual-context entries proposed.

## §6.2 Step 6 — Re-evaluation self-check

> *"Halt-resolution self-check for H2896A (tov) mti_id=884:*
> *— Active verses: 306*
> *— Verses re-evaluated this session: 141 (the previously-pending set)*
> *— Verses retained at prior classification: 165*
> *— Of the 141 newly-evaluated verses:*
> *    — Set-aside physical_only: 59*
> *    — Set-aside no_inner_being: 16*
> *    — Borderline-set-aside (no_inner_being with note): 3 (good-old-age verses)*
> *    — Relevant, assigned to existing groups: 14*
> *    — Relevant, assigned to new groups (pending DF-HR-002): 52*
> *— Group description amendments proposed: 0 (existing 6 groups unchanged)*
> *— New groups proposed: 3 (884-007, 884-008, 884-009)*
> *— Check: 59 + 16 + 3 + 14 + 52 = 144 ≠ 141*

**The arithmetic does not balance — let me recount.** From the decisions JSON: SET-ASIDE: 72; RELEVANT: 66; BORDERLINE-SETASIDE: 3. Total: 141. ✓

The narrative split: of the 72 set-aside, 59 physical_only + 13 no_inner_being = 72. (I miscounted earlier as 16.) Of the 66 relevant: 40 to 884-008 + 7 to 884-007 + 5 to 884-009 + 9 to 884-004 + 2 to 884-002 + 1 to 884-005 + 1 to 884-003 + 1 to 884-006 = 66. ✓

**Corrected arithmetic:** 59 (physical_only) + 13 (no_inner_being) + 3 (borderline-setaside no_inner_being) + 14 (relevant existing groups) + 52 (relevant new groups) = 141. ✓

> *"Total active rows post-apply: 165 (existing) + 141 (new) = 306 = active verse count. Coverage: 100%."*

## §6.2 Step 6 — Orphan-group check

> *"Orphan-group check for H2896A mti_id=884:*
> *— Pre-existing active groups: 6 (884-001 through 884-006)*
> *— New groups proposed: 3 (884-007, 884-008, 884-009)*
> *— Active verse counts per group after halt-resolution:*
> *    884-001 [unchanged]: prior count*
> *    884-002 [+2]: prior count + 2 (Pro 3:4, Pro 31:18)*
> *    884-003 [+1]: prior count + 1 (Ecc 2:3)*
> *    884-004 [+9]: prior count + 9 (comparatives + counsel evaluations)*
> *    884-005 [+1]: prior count + 1 (Neh 2:8)*
> *    884-006 [+1]: prior count + 1 (Jer 44:17)*
> *    884-007 [new]: 7 verses*
> *    884-008 [new]: 40 verses*
> *    884-009 [new]: 5 verses*
> *— Set-aside rows: 75 (group_id NULL per R1)*
> *— Orphan groups: NONE"*

## Per-term Annexure B summary

```
Term: H2896A (tov) — pleasant
mti_term_id: 884
OWNER for: goodness (registry 67)
Total verses: 306 | Newly classified this session: 141 | Set aside: 75 | Relevant: 66

Halt resolution:
  - 75 verses set aside (59 physical_only + 16 no_inner_being including 3 borderline)
  - 66 verses relevant: 14 placed in existing groups (884-002, 884-003, 884-004, 884-005, 884-006); 52 placed in 3 new groups proposed (884-007, 884-008, 884-009)
  - 3 new groups proposed (DF-HR-002): creation-evaluative-pronouncement (7); volitional-preference (40); inner well-being state (5)
  - 0 group description amendments to existing 6 groups
  - No anchor changes to existing groups; new anchors proposed for 3 new groups

Patch-contribution class: MIXED
  - 141 verse_context inserts (66 relevant + 75 set-aside)
  - 3 verse_context_group inserts (884-007, 884-008, 884-009)
  → Legacy VERSECONTEXT patch (per VC §6.3 Step 3 — MIXED routing)

Total operations on this term: 144
```

## SB / SD observations

- **OBS-HR-003** — H2896A's pending corpus revealed a clean methodology pattern. The prior session had classified verses where *tov* engages inner-being content directly through the term (wisdom-good, divine-good, moral-good, experiential-good, covenantal-good, prophetic-verdict-not-good — the 6 existing groups) and left pending the verses where *tov* either (a) is physical-quality of objects/persons/land, or (b) is part of an idiomatic merism, or (c) names a volitional-preference, or (d) names an inner-state-of-well-being. The classification itself reveals that *tov*'s corpus genuinely splits between physical-aesthetic uses (set-aside) and inner-being-engaged uses (groupable). The 3 new groups extend the group set to cover the previously-uncovered inner-being-engaged facets.

- **PPO-VCB013-002** — Across all three halt-resolution terms (H2181, H8549G, H2896A) the partial-completion pattern is now confirmed as the same methodology: prior sessions identified inner-being-engaged uses and left physically-only / aesthetically-only / idiomatically-only uses as implicit set-asides without writing rows. The post-M39 skeleton-free model requires explicit set-aside rows. **The halt-resolution work for these three terms together produces 198 new verse_context inserts (some relevant, mostly set-aside), 3 new verse_context_groups (all on H2896A), 1 group description update (H2181 1221-004), and adds these 3 terms to the VCB-013 patches.**

## Patch routing decision

**Term H2896A mti_id=884: patch-contribution class = MIXED. Legacy VERSECONTEXT patch will cover this term. Operations:**
- 3 × insert on `verse_context_group` (new groups 884-007, 884-008, 884-009)
- 141 × insert on `verse_context` (66 relevant assignments + 75 set-asides)

**Total: 144 operations on this term.**


---

# 8. Halt-resolution session close

## 8.1 Patches produced

| File | Type | Term | Operations |
|---|---|---|---|
| `wa-vcb013hr-patch-vcnew-v1-20260425.json` | VCNEW | H8549G (mti=934) | 45 inserts (all `physical_only` set-aside) |
| `wa-vcb013hr-patch-versecontext-h2181-v1-20260425.json` | VERSECONTEXT (legacy) | H2181 (mti=1221) | 12 inserts (10 set-aside + 2 relevant) + 1 group_update on 1221-004 |
| `wa-vcb013hr-patch-versecontext-h2896a-v1-20260425.json` | VERSECONTEXT (legacy) | H2896A (mti=884) | 144 ops: 3 group_inserts (884-007, 884-008, 884-009) + 141 verse_context inserts |

**Total: 202 operations across 3 patches; 198 previously-pending verses now classified; 3 new groups created.**

## 8.2 Pre-submission validation

All 11 checks passed (R1, R2, R3, R4 compliance; op_id format/uniqueness; coverage; terms_covered ↔ input_versions parity; no overlap between patches; governing_instruction set; total_operations matches operations.length).

## 8.3 Apply order

The original VCB-013 patches (vcrevise v1, versecontext v1 for G1258, vcsbflags v1) plus these halt-resolution patches form the complete VCB-013 output set. Recommended apply order:

1. `wa-vcb013-patch-vcrevise-v1-20260425.json` — original 11 terms
2. `wa-vcb013-patch-versecontext-v1-20260425.json` — G1258 single-verse correction
3. `wa-vcb013-patch-vcsbflags-v1-20260425.json` — Session B flags
4. **`wa-vcb013hr-patch-vcnew-v1-20260425.json`** — H8549G halt-resolution
5. **`wa-vcb013hr-patch-versecontext-h2181-v1-20260425.json`** — H2181 halt-resolution
6. **`wa-vcb013hr-patch-versecontext-h2896a-v1-20260425.json`** — H2896A halt-resolution

The halt-resolution patches do not overlap `terms_covered` with the original patches (the halted terms were excluded from the originals), so apply order between blocks (1-3) and (4-6) is independent. Within each block the patches do not conflict.

## 8.4 Registry advancement projection (post-apply)

With the halted terms now resolved, the projection in the original session-log changes:

| Registry | OWNER terms | Status post-apply |
|---|---|---|
| 067 goodness | 885 ✓, 886 ✓, 884 ✓ (was excluded; now vc_completed via H2896A halt-resolution) | Now able to advance to Complete |
| 069 gratitude | 5480 ✓, 891 ✓, 5481 ✓ | Already projected to advance |
| 092 integrity | 935 ✓, 933 ✓, 934 ✓ (was excluded; now vc_completed via H8549G halt-resolution) | Now able to advance to Complete |
| 127 reasoning | 1080 ✓, 6065 ✓, 1081 ✓ | Already projected to advance |
| 171 whoredom | 1220 ✓, 1222 ✓, 1221 ✓ (was excluded; now vc_completed via H2181 halt-resolution) | Now able to advance to Complete |

**All five registries in VCB-013 now able to advance to verse_context_status = Complete after apply** (subject to no other non-complete OWNER + XREF-via-OWNER terms outside this session's scope).

## 8.5 Instruction update — v3_9 → v3_10

The researcher requested a careful review of the VC instruction wording to ensure the spirit of the halt-resolution work is captured for future sessions. Three guidance gaps were identified and addressed in v3_10:

1. **§3.2c — Cluster-treatment discipline** (new). Cluster-level filter reasoning is permitted on homogeneous verse blocks (e.g. H8549G's 45 sacrificial-formula verses) but only after every verse is individually read and the homogeneity established by reading. Per-verse rows are always written. Any verse departing from the cluster pattern receives individual treatment.
2. **§6.2 Step 2 — Halt resolution discipline** (strengthened). The partial-completion halt is *stop-and-investigate*, not *stop-and-exclude*. On researcher instruction, every previously-pending verse is read, filtered, and given an explicit `verse_context` row — relevant or set-aside with controlled-vocabulary reason. The halted term re-enters the patch flow per §6.3 Step 3 routing.
3. **§6.5.0 — In-session resolution before flagging** (new). Findings the classifier can resolve by reading must be resolved by reading in-session, not deferred to the flags register. Flagging is reserved for genuine researcher-judgement questions. The classifier-resolvable / researcher-resolvable distinction is made explicit.

**File:** `wa-versecontext-instruction-v3_10-20260425.md`. Supersedes v3_9. Guidance-only update; no schema change; no applicator change.

## 8.6 Files produced this halt-resolution session

| File | Purpose |
|---|---|
| `wa-vcb013-haltresolution-obslog-v1_0-20260425.md` | This file — full per-verse reasoning across H2181, H8549G, H2896A |
| `wa-vcb013hr-patch-vcnew-v1-20260425.json` | H8549G 45 inserts |
| `wa-vcb013hr-patch-versecontext-h2181-v1-20260425.json` | H2181 12 inserts + 1 group_update |
| `wa-vcb013hr-patch-versecontext-h2896a-v1-20260425.json` | H2896A 144 ops (3 group_inserts + 141 verse_context_inserts) |
| `wa-versecontext-instruction-v3_10-20260425.md` | VC instruction update — codifies the discipline that produced this session's outcome |

All files dual-written to `/home/claude/work/` and `/mnt/user-data/outputs/`.

*Halt-resolution session VCB-013-HR closed 2026-04-25.*

